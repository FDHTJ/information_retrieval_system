import com.auth0.jwt.interfaces.Claim;
import com.example.information_retrieval.pojo.Article;
import com.example.information_retrieval.sevice.EmailService;
import com.example.information_retrieval.sevice.Impl.EmailServiceImpl;
import com.example.information_retrieval.utills.JWTUtil;
import com.example.information_retrieval.utills.PorterStremAnalyzer;
import com.google.gson.Gson;
import org.apache.lucene.document.*;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class testClass {
    @Test
    public void create(){
        // 索引存储的路径
        String indexDir = "newIndexAll";
        File[] files = new File("D:\\infomation_retrieval\\information_retireval\\src\\test\\java\\com\\example\\information_retrieval\\oriPDFSjson").listFiles();
        try {
            // 创建索引存储的Directory对象
            Directory directory = FSDirectory.open(Paths.get(indexDir));
            // 使用SmartChineseAnalyzer进行中文分词
            PorterStremAnalyzer analyzer = new PorterStremAnalyzer(Collections.emptySet());
            // 创建IndexWriterConfig对象
            IndexWriterConfig config = new IndexWriterConfig(analyzer);
            // 创建IndexWriter对象
            IndexWriter indexWriter = new IndexWriter(directory, config);
            Gson g=new Gson();
            assert files != null;
            int i=0;
            for(File f : files){
                System.out.println(i++);
                Article article=g.fromJson(new FileReader(f.getAbsolutePath()),Article.class);
                // 创建一个Document对象
                Document doc = new Document();
                doc.add(new TextField(Article.WRITERS,String.join(" ; ",article.getWriters()), Field.Store.YES));
                doc.add(new TextField(Article.KEYWORDS,String.join(" ; ",article.getKeywords()), Field.Store.YES));
                doc.add(new TextField(Article.ORGNAMES,String.join(" ; ",article.getOrgNames()), Field.Store.YES));
                doc.add(new TextField(Article.ADDRESSES,String.join(" ; ",article.getAddresses()), Field.Store.YES));
                doc.add(new TextField(Article.FULLTEXT,article.getFulltext(), Field.Store.YES));
                doc.add(new TextField(Article.TITLE,article.getTitle(), Field.Store.YES));
                doc.add(new TextField(Article.DIGEST,article.getDigest(), Field.Store.YES));
                doc.add(new StoredField(Article.DATE,article.getDate()));
                doc.add(new StoredField(Article.FILE_NAME,article.getFileName().replace(".xml",".pdf")));
                // 将Document对象写入索引库
                indexWriter.addDocument(doc);

            }

            // 关闭IndexWriter对象
            indexWriter.close();
            directory.close();
            System.out.println("索引创建成功！");
        } catch (IOException e) {

            System.out.println("索引创建失败！");
        }
    }

    @Test
    public void te(){
        JWTUtil jwtUtil=new JWTUtil();
        Map<String,Object> claims=new HashMap<>();
        claims.put("userName","12345789");
        claims.put("password","123456789");
        String accessKey="information-retrieval-tj-yjf-fdh";
        long ttl =7200000;
        String token=jwtUtil.getJWT(accessKey,ttl,claims);
        Claim res=jwtUtil.parseJWT(accessKey,"123456");

    }
}
