package com.example.information_retrieval.config;

import lombok.extern.slf4j.Slf4j;
import org.apache.tika.Tika;
import org.apache.tika.config.TikaConfig;
import org.apache.tika.detect.Detector;
import org.apache.tika.parser.AutoDetectParser;
import org.apache.tika.parser.Parser;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;

import java.io.InputStream;

@Configuration
@Slf4j
public class TikaConfiguration {
    @Bean
    public Tika tika(ResourceLoader resourceLoader) throws Exception {
        log.info("开始创建tika...");
        TikaConfig config = new TikaConfig();
        Detector detector = config.getDetector();
        Parser parser = new AutoDetectParser(config);
        return new Tika(detector, parser);
    }
}
