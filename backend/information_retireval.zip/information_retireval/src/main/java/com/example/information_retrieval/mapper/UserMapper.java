package com.example.information_retrieval.mapper;

import com.example.information_retrieval.dataBasePojo.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

@Mapper
public interface UserMapper {
    @Select("select * from thesis_retrieval.user where user_name=#{userName}")
    List<User> getByUserName(String userName);

    void save(User user);
    @Select("select * from thesis_retrieval.user where user.email =#{email}")
    List<User> getByEmail(String email);

    void update(User user);
    @Select("select * from thesis_retrieval.user where user_id=#{userId}")
    List<User> getByUSERId(Integer userId);
}
