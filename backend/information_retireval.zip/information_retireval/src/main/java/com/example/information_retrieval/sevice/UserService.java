package com.example.information_retrieval.sevice;

import com.example.information_retrieval.dataBasePojo.*;
import com.example.information_retrieval.result.PageResult;
import org.apache.tika.exception.TikaException;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

public interface UserService {
    void addHistory(UserHistory userHistory);

    List<UserHistory> getHistory(Integer userId);

    void deleteHistory(List<Integer> ids);

    void register(User user) throws Exception;

    UserVo login(String name, String password) throws Exception;
    void update(User user);

    String changeAvatar(MultipartFile file,Integer userId) throws Exception;

    void verifyCode(String target, String verificationCode) throws Exception;

    void changePassword(User user) throws Exception;

    void changeUserName(User user) throws Exception;

    void uploadFile(MultipartFile file, Integer userId) throws Exception;

    List<UploadRecord> getUploadRecord(Integer userId);

    String analysis(MultipartFile file) throws IOException, TikaException;

    List<String> getAllFolder(Integer userId);

    PageResult getCollection(Integer userId, String domain, Integer page, Integer pageSize);

    void deleteFolder(Integer userId, String domain) throws Exception;

    void addFolder(Integer userId, String newDomain) throws Exception;

    void cancelCollected(Integer id);

    void addCollection(Collection collection);
}
