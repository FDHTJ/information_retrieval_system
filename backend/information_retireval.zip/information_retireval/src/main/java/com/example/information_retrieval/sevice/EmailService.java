package com.example.information_retrieval.sevice;

public interface EmailService {
    void sendVerificationEmail(String target, String subject, String text, Boolean isRegister) throws Exception;

}
