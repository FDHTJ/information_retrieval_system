package com.example.information_retrieval.sevice.Impl;

import com.example.information_retrieval.config.TikaConfiguration;
import com.example.information_retrieval.dataBasePojo.Collection;
import com.example.information_retrieval.dataBasePojo.UploadRecord;
import com.example.information_retrieval.dataBasePojo.User;
import com.example.information_retrieval.dataBasePojo.UserHistory;
import com.example.information_retrieval.dataBasePojo.UserVo;
import com.example.information_retrieval.mapper.CollectionMapper;
import com.example.information_retrieval.mapper.UploadRecordMapper;
import com.example.information_retrieval.mapper.UserHistoryMapper;
import com.example.information_retrieval.mapper.UserMapper;
import com.example.information_retrieval.property.JWTProperties;
import com.example.information_retrieval.result.PageResult;
import com.example.information_retrieval.sevice.RedisService;
import com.example.information_retrieval.sevice.UserService;
import com.example.information_retrieval.utills.AliOssUtil;
import com.example.information_retrieval.utills.JWTUtil;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import lombok.extern.slf4j.Slf4j;
import org.apache.tika.Tika;
import org.apache.tika.exception.TikaException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.DigestUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.*;

@Service
@Slf4j
public class UserServiceImpl implements UserService {
    @Autowired
    private RedisService redisService;
    @Autowired
    UserHistoryMapper userHistoryMapper;
    @Autowired
    UserMapper userMapper;
    @Autowired
    JWTProperties jwtProperties;
    @Autowired
    private AliOssUtil aliOssUtil;
    @Autowired
    private UploadRecordMapper uploadRecordMapper;
    @Autowired
    private Tika tika;
    @Autowired
    CollectionMapper collectionMapper;
    private String uploadFilePath="D:\\infomation_retrieval\\information_retireval\\uploadFile";

    @Override
    public void addHistory(UserHistory userHistory) {
        String temp=userHistory.getTitle();
        if (temp.contains("</b>")){
            temp=temp.replace("</b>","");
            temp=temp.replace("<b style=\"color:red; padding-right:7px;padding-left:7px\">","");
            userHistory.setTitle(temp);
        }
        userHistory.setDate(LocalDateTime.now());
        userHistoryMapper.add(userHistory);
    }

    @Override
    public List<UserHistory> getHistory(Integer userId) {
        LocalDateTime endTime=LocalDateTime.now();
        LocalDateTime startTime=endTime.minusDays(7);
        List<UserHistory> res=userHistoryMapper.get(userId,startTime,endTime);
        return res;
    }

    @Override
    public void deleteHistory(List<Integer> ids) {
        userHistoryMapper.deleteHistory(ids);
    }

    @Override
    @Transactional
    public void register(User user) throws Exception {
        List<User> sameUserNameUsers = userMapper.getByUserName(user.getUserName());
        if(sameUserNameUsers==null || sameUserNameUsers.isEmpty()){
            //说明没有相同的用户名
            String vertificationCode = redisService.getVertificationCode(user.getEmail());
            if(!vertificationCode.equals(user.getVertificationCode())){
                throw new Exception("VertificationCode is not correct !");
            }
            //使用MD5进行加密
            user.setPassword(DigestUtils.md5DigestAsHex(user.getPassword().getBytes()));
            //将新账号加入到数据库中

            userMapper.save(user);
            Collection collection=Collection.builder()
                    .userId(user.getUserId())
                    .domain("all")
                    .build();
            collectionMapper.save(collection);
        }else{
            throw new Exception("The UserName has been used !");
        }
    }

    @Override
    public UserVo login(String name, String password) throws Exception {
        List<User> byUserName=userMapper.getByUserName(name);
        List<User> byEmail=userMapper.getByEmail(name);
        if((byUserName==null||byUserName.isEmpty())&&(byEmail==null||byEmail.isEmpty())){
            //说明用户不存在
            throw new Exception("The account is not existed !");
        }
        User user=byEmail.isEmpty() ? byUserName.get(0):byEmail.get(0);
        String pwd=DigestUtils.md5DigestAsHex(password.getBytes());
        if(!pwd.equals(user.getPassword())){
            throw new Exception("Password is not correct !");
        }
        //说明验证通过

        Map<String, Object> claims=new HashMap<>();
        claims.put("userName",user.getUserName());
        claims.put("email",user.getEmail());
        claims.put("password",user.getPassword());
        String token= JWTUtil.getJWT(jwtProperties.getAccessKey(),jwtProperties.getTtl(),claims);
        UserVo userVo=UserVo.builder()
                .userId(user.getUserId())
                .email(user.getEmail())
                .userName(user.getUserName())
                .avatar(user.getAvatar())
                .isManager(user.getIsManager())
                .token(token)
                .build();
        return userVo;
    }

    @Override
    public void update(User user) {
        userMapper.update(user);
    }

    @Override
    public String changeAvatar(MultipartFile file,Integer userId) throws Exception {
        try {
            String fileName = file.getOriginalFilename();
            String extent = fileName.substring(fileName.lastIndexOf("."));
            String name = UUID.randomUUID().toString();
            //文件请求路径
            String uploadName = aliOssUtil.upload(file.getBytes(), (name + extent));
            User user=User.builder()
                    .userId(userId)
                    .avatar(uploadName).build();
            update(user);
            return uploadName;
        } catch (IOException e) {
            throw  new Exception("Failed !");
        }
    }
    @Override
    public void uploadFile(MultipartFile file, Integer userId) throws Exception {
        try{
            String OriginalFilename = file.getOriginalFilename();
            String extent = OriginalFilename.substring(OriginalFilename.lastIndexOf("."));
            String name = UUID.randomUUID().toString();
            String fileName=name+extent;
            Path path= Paths.get(uploadFilePath,fileName);
            Files.write(path,file.getBytes());
            log.info(fileName);
            UploadRecord uploadRecord=UploadRecord.builder()
                    .userId(userId)
                    .fileName(fileName)
                    .uploadDate(LocalDateTime.now())
                    .state(UploadRecord.WAIT_FOR_AUDIT)
                    .originalFileName(OriginalFilename)
                    .build();
            uploadRecordMapper.save(uploadRecord);

        } catch (IOException e) {
            e.printStackTrace();
            throw new Exception("Failed !");
        }
    }

    @Override
    public List<UploadRecord> getUploadRecord(Integer userId) {
        List<UploadRecord>uploadRecords=uploadRecordMapper.getUploadRecordByUserId(userId);
        return uploadRecords;
    }

    @Override
    public String analysis(MultipartFile file) throws IOException, TikaException {
        try {
            String res=tika.parseToString(file.getInputStream());
            return res;
        }catch (Exception e){
            throw e;
        }
    }

    @Override
    public List<String> getAllFolder(Integer userId) {
        List<String> folders=collectionMapper.getAllFolderByUserId(userId);
        return folders;
    }

    @Override
    public PageResult getCollection(Integer userId, String domain, Integer page, Integer pageSize) {
        PageHelper.startPage(page,pageSize);
        Page<Collection> collections=null;
        if(domain.equals("all")){
            collections=collectionMapper.getCollection(userId,null);
        }else{
            collections=collectionMapper.getCollection(userId,domain);
        }
        return new PageResult(collections.getTotal(),collections.getResult());
    }

    @Override
    public void deleteFolder(Integer userId, String domain) throws Exception {
        if(domain.equals("all")){
            throw new Exception("This folder can not be deleted !");
        }
        collectionMapper.deleteFolder(userId,domain);
    }

    @Override
    public void addFolder(Integer userId, String newDomain) throws Exception {
        List<Collection> collectionsByDomain=collectionMapper.getCollection(null,newDomain);
        if(!(collectionsByDomain==null || collectionsByDomain.isEmpty())){
            throw new Exception("Already existed !");
        }
        Collection collection=Collection.builder()
                .userId(userId)
                .domain(newDomain).build();
        collectionMapper.save(collection);
    }

    @Override
    public void cancelCollected(Integer id) {
        collectionMapper.deleteById(id);
    }

    @Override
    public void addCollection(Collection collection) {
        String t=collection.getTitle();
        t=t.replace("<b style=\"color:red; padding-right:7px;padding-left:7px\">","").replace("</b>","");
        collection.setTitle(t);
        collectionMapper.save(collection);
    }

    @Override
    public void verifyCode(String target, String verificationCode) throws Exception {
        String code=redisService.getVertificationCode(target);
        if(!code.equals(verificationCode)){
            throw  new Exception("VerificationCode is not correct or overdued !");
        }

    }

    @Override
    public void changePassword(User user) throws Exception {
        verifyCode(user.getEmail(), user.getVertificationCode());
        User user1=null;
        try{
            user1=userMapper.getByEmail(user.getEmail()).get(0);
        }catch (Exception e){
            throw new Exception("Account is not existed");
        }
        String newPassword=DigestUtils.md5DigestAsHex(user.getPassword().getBytes());
        user1.setPassword(newPassword);
        userMapper.update(user1);
    }


    @Override
    public void changeUserName(User user) throws Exception {
        String newUserName=user.getUserName();
        List<User> byUserName = userMapper.getByUserName(newUserName);
        if(!(byUserName==null || byUserName.isEmpty())){
            throw new Exception("The userName has existed !");
        }
        User originUser=userMapper.getByUSERId(user.getUserId()).get(0);
        originUser.setUserName(newUserName);
        userMapper.update(originUser);
    }


}
