package com.example.information_retrieval.dataBasePojo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Collection {
    Integer id;
    String title;
    Integer userId;
    String domain;
}
