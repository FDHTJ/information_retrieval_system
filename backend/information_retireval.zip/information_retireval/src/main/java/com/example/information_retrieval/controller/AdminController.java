package com.example.information_retrieval.controller;

import com.example.information_retrieval.dataBasePojo.UploadRecord;
import com.example.information_retrieval.result.PageResult;
import com.example.information_retrieval.result.Result;
import com.example.information_retrieval.sevice.AdminService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@Slf4j
@RequestMapping("/admin")
@Tag(name="管理员接口")
public class AdminController {
    @Autowired
    AdminService adminService;
    @GetMapping("/get_user_info")
    @Operation(summary = "获取用户信息")
    Result<PageResult>  getUserInfo(@RequestParam("page")Integer page,@RequestParam("pageSize") Integer pageSize){
        PageResult result=adminService.getUserInfo(page,pageSize);
        return Result.success(result);
    }
    @GetMapping("/get_upload_record")
    @Operation(summary = "获取全部待审核的记录")
    Result<PageResult> getUploadRecord(@RequestParam("page")Integer page,@RequestParam("pageSize") Integer pageSize){
        PageResult result=adminService.getUploadRecord(page,pageSize);
        return  Result.success(result);
    }
    @PostMapping("/change_upload_record_state")
    @Operation(summary = "改变审核状态")
    Result changeUploadRecordState(@RequestBody UploadRecord uploadRecord){
        adminService.changeUploadRecordState(uploadRecord);
        return Result.success();

    }
    @DeleteMapping("/delete_upload_record")
    @Operation(summary = "删除一条待审核记录")
    Result deleteUploadRecord(@RequestParam("id") Integer id){
        adminService.deleteUploadRecord(id);
        return Result.success();

    }
}
