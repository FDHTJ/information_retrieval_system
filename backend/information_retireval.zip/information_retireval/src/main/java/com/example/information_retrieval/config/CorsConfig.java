package com.example.information_retrieval.config;

import com.example.information_retrieval.interceptor.JWTInterceptor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;


@Configuration
@Slf4j
public class CorsConfig implements WebMvcConfigurer {
    @Autowired
    JWTInterceptor jwtInterceptor;
    @Override
    public void addCorsMappings(CorsRegistry registry) {
        //用来配置前端
        registry.addMapping("/**")
                .allowedOrigins("http://localhost:5173")
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(true);

    }

    @Override
    public void addInterceptors(InterceptorRegistry registry){
        log.info("开始注册自定义拦截器....");
        registry.addInterceptor(jwtInterceptor)
                .addPathPatterns("/user/**")
                .excludePathPatterns("/user/register")
                .excludePathPatterns("/user/email")
                .excludePathPatterns("/user/login")
                .excludePathPatterns("/user/verify_code")
                .excludePathPatterns("/user/change_password")
                .addPathPatterns("/admin/**");
    }
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/uploadFile/**")
                .addResourceLocations("file:D:\\infomation_retrieval\\information_retireval\\uploadFile/");

    }
}