package com.example.information_retrieval.property;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "retrieval.jwt")
@Data
public class JWTProperties {
    String accessKey;
    long ttl;
    String tokenName;
}
