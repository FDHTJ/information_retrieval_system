package com.example.information_retrieval.controller;
import com.example.information_retrieval.pojo.ArticleData;
import com.example.information_retrieval.result.Result;
import com.example.information_retrieval.sevice.SearchService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.search.highlight.InvalidTokenOffsetsException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

@RestController
@Slf4j
@RequestMapping("/search")
@Tag(name="检索相关接口")
public class SearchController {
    @Autowired
    SearchService searchService;
    @GetMapping("/get_search_result")
    @Operation(summary = "获取搜索结果")
    Result<List<ArticleData>> getSearchResult(@RequestParam(name="dateChoice") Integer dateChoice,@RequestParam(name = "currentPage") Integer currentPage, @RequestParam(name = "field") String field,@RequestParam(name="queryText")String queryText) throws InvalidTokenOffsetsException, IOException, ParseException {
        List<ArticleData> result = searchService.getSearchResult(field, queryText,currentPage,dateChoice);
        return Result.success(result);
    }
    @GetMapping("get_suggest")
    @Operation(summary = "获取输入建议")
    Result<List<String>> getSuggest(@RequestParam(name = "field") String field,@RequestParam(name="queryText")String queryText) throws InvalidTokenOffsetsException, IOException, ParseException {
        List<String> result = searchService.getSuggest(field, queryText);
        return Result.success(result);
    }
    @GetMapping("random_look")
    @Operation(summary = "随便看看")
    Result<List<ArticleData>> randomLook() throws FileNotFoundException {
        List<ArticleData> res=searchService.getRandomLook();
        return Result.success(res);
    }
}
