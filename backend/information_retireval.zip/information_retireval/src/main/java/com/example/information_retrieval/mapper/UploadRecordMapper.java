package com.example.information_retrieval.mapper;

import com.example.information_retrieval.dataBasePojo.UploadRecord;
import com.github.pagehelper.Page;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface UploadRecordMapper {
    void save(UploadRecord uploadRecord);
    @Select("select * from thesis_retrieval.upload_record where user_id=#{userId} order by upload_date desc")
    List<UploadRecord> getUploadRecordByUserId(Integer userId);
    @Select("select * from thesis_retrieval.upload_record order by upload_date desc")
    Page<UploadRecord> getAllUploadRecord();

    void update(UploadRecord uploadRecord);
    @Delete("delete  from thesis_retrieval.upload_record where id =#{id}")
    void deleteById(Integer id);
}
