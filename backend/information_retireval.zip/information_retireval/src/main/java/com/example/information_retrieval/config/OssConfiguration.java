package com.example.information_retrieval.config;

import com.example.information_retrieval.property.AliOssProperties;
import com.example.information_retrieval.utills.AliOssUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@Slf4j
//阿里云配置类
public class OssConfiguration {
    @Bean
    @ConditionalOnMissingBean
    //当没有这个对象的时候再创建对象
    public AliOssUtil aliOssUtil(AliOssProperties aliOssProperties){
    log.info("开始创建aliyunossutil");
       return new AliOssUtil(aliOssProperties.getEndpoint(),
               aliOssProperties.getAccessKeyId(),
               aliOssProperties.getAccessKeySecret(),
               aliOssProperties.getBucketName());
    }
}
