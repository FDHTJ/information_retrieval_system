package com.example.information_retrieval.sevice;

public interface RedisService {
    void setVertificationCode(String key,String value);
    String getVertificationCode(String key) throws Exception;
}
