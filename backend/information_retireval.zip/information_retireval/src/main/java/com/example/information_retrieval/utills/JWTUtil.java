package com.example.information_retrieval.utills;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.Claim;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.util.Date;
import java.util.Map;
@Data
@AllArgsConstructor
@Slf4j
public class JWTUtil {
    public static String getJWT(String accessKey, long ttl, Map<String,Object> claims){
        Algorithm algorithm=Algorithm.HMAC256(accessKey);
        long currentTimeMills=System.currentTimeMillis();
        ttl+=currentTimeMills;
        return JWT.create()
                .withClaim("userInfo",claims)
                .withIssuedAt(new Date(currentTimeMills))
                .withExpiresAt(new Date(ttl))
                .sign(algorithm);
    }
    public static Claim parseJWT(String accessKey, String token){
        Algorithm algorithm=Algorithm.HMAC256(accessKey);
        JWTVerifier jwtVerifier=JWT.require(algorithm).build();
        try {
            return jwtVerifier.verify(token).getClaims().get("userInfo");
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

}
