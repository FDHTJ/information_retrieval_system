package com.example.information_retrieval.dataBasePojo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UploadRecord {
    public static final String WAIT_FOR_AUDIT="Wait for auditing ";
    public static final String PASS="Pass";
    public static final String FAILED="Failed";
    Integer id;
    Integer userId;
    LocalDateTime uploadDate;
    String state;
    String fileName;
    String originalFileName;
}
