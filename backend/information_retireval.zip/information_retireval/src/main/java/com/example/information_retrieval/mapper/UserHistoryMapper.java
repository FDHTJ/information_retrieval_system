package com.example.information_retrieval.mapper;

import com.example.information_retrieval.dataBasePojo.UserHistory;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.time.LocalDateTime;
import java.util.List;

@Mapper
public interface UserHistoryMapper {

    void add(UserHistory userHistory);
    @Select("select * from thesis_retrieval.user_history where userId=#{userId} and date between #{startTime} and #{endTime} order by date desc")
    List<UserHistory> get(Integer userId, LocalDateTime startTime, LocalDateTime endTime);
    void deleteHistory(List<Integer> ids);
}
