package com.example.information_retrieval.sevice;

import com.example.information_retrieval.dataBasePojo.UploadRecord;
import com.example.information_retrieval.result.PageResult;

public interface AdminService {
    PageResult getUserInfo(Integer page, Integer pageSize);

    PageResult getUploadRecord(Integer page, Integer pageSize);

    void changeUploadRecordState(UploadRecord uploadRecord);

    void deleteUploadRecord(Integer id);
}
