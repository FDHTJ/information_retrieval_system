package com.example.information_retrieval.utills;

import org.apache.lucene.analysis.*;
import org.apache.lucene.analysis.en.PorterStemFilter;
import org.apache.lucene.analysis.miscellaneous.SetKeywordMarkerFilter;
import org.apache.lucene.analysis.standard.StandardTokenizer;

import java.util.Set;

public class PorterStremAnalyzer extends Analyzer {
    //建立索引时的分析器
    private final Set<?> stemExlusionSet;
    //在进行porter算法提取的时候，哪些词会被排除

    public PorterStremAnalyzer(Set<?> stemExlusionSet) {
        this.stemExlusionSet = stemExlusionSet;
    }

    @Override
    protected TokenStreamComponents createComponents(String s) {
        final Tokenizer source=new StandardTokenizer();
        //创建将字符串转换为小写字符的tokenSream
        TokenStream result=new LowerCaseFilter(source);
        result=new PorterStemFilter(result);
        if(!stemExlusionSet.isEmpty()){
            //如果需要排除的不为空,就应用上原来的
            result=new SetKeywordMarkerFilter(result, CharArraySet.copy(stemExlusionSet));
        }
        return new TokenStreamComponents(source,result);
    }
}
