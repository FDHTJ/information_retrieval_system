package com.example.information_retrieval.mapper;

import com.example.information_retrieval.dataBasePojo.Collection;
import com.github.pagehelper.Page;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface CollectionMapper {
    void save(Collection collection);
    @Select("select distinct domain from thesis_retrieval.collection where user_id=#{userId} ")
    List<String> getAllFolderByUserId(Integer userId);

    Page<Collection> getCollection(Integer userId, String domain);
    @Delete("delete from thesis_retrieval.collection where user_id=#{userId} and domain=#{domain}")
    void deleteFolder(Integer userId, String domain);
    @Delete("delete  from thesis_retrieval.collection where id =#{id}")
    void deleteById(Integer id);
}
