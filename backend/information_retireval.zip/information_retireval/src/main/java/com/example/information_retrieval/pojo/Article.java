package com.example.information_retrieval.pojo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Article {
    public static final String FILE_NAME="fileName";
    public static final String TITLE    ="title";
    public static final String DIGEST   ="digest";
    public static final String WRITERS  ="writers";
    public static final String KEYWORDS ="keywords";
    public static final String FULLTEXT ="fulltext";
    public static final String ADDRESSES="addresses";
    public static final String ORGNAMES ="orgNames";
    public static final String DATE     ="date";
    //文章的路径
    String fileName;
    //文章标题
    String title;
    //摘要
    String digest;
    //日期
    String date;
    //作者
    List<String> writers;
    //关键词
    List<String> keywords;
    //全文
    String fulltext;
    //地址
    List<String> addresses;
    //组织
    List<String> orgNames;
}
