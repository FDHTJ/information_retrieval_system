package com.example.information_retrieval.pojo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ArticleData {
    //文章的路径
    String fileName;
    //文章标题
    String title;
    //摘要
    String digest;
    //日期
    String date;
    //作者
    String writers;
    //关键词
    String keywords;
    //地址
    String addresses;
    //组织
    String orgNames;
}
