package com.example.information_retrieval.controller;

import com.example.information_retrieval.dataBasePojo.*;
import com.example.information_retrieval.result.PageResult;
import com.example.information_retrieval.result.Result;
import com.example.information_retrieval.sevice.EmailService;
import com.example.information_retrieval.sevice.RedisService;
import com.example.information_retrieval.sevice.UserService;
import com.example.information_retrieval.utills.AliOssUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.annotations.Delete;
import org.apache.tika.exception.TikaException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.naming.ldap.PagedResultsControl;
import java.io.IOException;
import java.util.List;
import java.util.UUID;


@RestController
@Slf4j
@RequestMapping("/user")
@Tag(name="用户相关接口")
public class UserController {

    @Autowired
    private UserService userService;
    @Autowired
    private EmailService emailService;

    @PostMapping("add_history")
    @Operation(summary = "添加浏览记录")
    Result addHistory(@RequestBody UserHistory userHistory){
        userService.addHistory(userHistory);
        return Result.success();
    }
    @GetMapping("get_history")
    @Operation(summary = "获取浏览记录")
    Result<List<UserHistory>> getHistory(@RequestParam("userId")Integer userId){
        List<UserHistory> res=userService.getHistory(userId);
        return Result.success(res);
    }
    @DeleteMapping("/delete_history")
    @Operation(summary = "删除浏览记录")

    Result deleteHistory(@RequestParam("historyIds") List<Integer> ids){
        userService.deleteHistory(ids);
    return Result.success();
    }
    @PostMapping("/register")
    @Operation(summary = "注册")

    Result register(@RequestBody User user) throws Exception {
        userService.register(user);
        return  Result.success();
    }
    @PostMapping("/email")
    @Operation(summary = "发送邮件")

    Result sendEmail(@RequestParam("target") String target, @RequestParam("isRegister") Boolean isRegister) throws Exception {
        emailService.sendVerificationEmail(target,"查收验证码","",isRegister);
        return Result.success();

    }
    @PostMapping("/login")
    @Operation(summary = "登录")

    Result<UserVo> login(@RequestParam("name") String name, @RequestParam("password") String password) throws Exception {
        UserVo userVo=userService.login(name,password);
        return Result.success(userVo);
    }
    @PostMapping("/change_avatar")
    @Operation(summary = "更换头像")

    Result changeAvatar(MultipartFile file,@RequestParam("userId") Integer userId) throws Exception {
        String path= userService.changeAvatar(file,userId);
        return  Result.success(path);
    }
    @PostMapping("verify_code")
    @Operation(summary = "验证验证码")

    Result verfyCode(@RequestParam("target") String target,@RequestParam("verificationCode") String verificationCode) throws Exception {
        userService.verifyCode(target,verificationCode);
        return Result.success();
    }
    @PostMapping("change_password")
    @Operation(summary = "修改密码")

    Result changePassword(@RequestBody User user) throws Exception {
        userService.changePassword(user);
        return Result.success();
    }
    @PostMapping("change_user_name")
    @Operation(summary = "修改用户名")

    Result changeUserName(@RequestBody User user) throws Exception {
        userService.changeUserName(user);
        return  Result.success();

    }
    @PostMapping("/upload")
    @Operation(summary = "上传文献")

    Result uploadFile(@RequestParam("file") MultipartFile file,@RequestParam("userId") Integer userId) throws Exception {
        userService.uploadFile(file,userId);
        return Result.success();
    }
    @GetMapping("/get_upload_record")
    @Operation(summary = "获取上传记录")

    Result<List<UploadRecord>> getUploadRecord(@RequestParam("userId")Integer userId){
        List<UploadRecord> uploadRecords=userService.getUploadRecord(userId);
        return Result.success(uploadRecords);
    }
    @PostMapping("/analysis")
    @Operation(summary = "解析文章")

    Result<String> analysis(@RequestParam("file") MultipartFile file) throws TikaException, IOException {
        String res=userService.analysis(file);
        return Result.success(res);
    }
    @GetMapping("/get_all_folder")
    @Operation(summary = "获取全部收藏分类")

    Result<List<String>> getAllFolder(@RequestParam("userId") Integer userId){
        List<String>  folders=userService.getAllFolder(userId);
        return Result.success(folders);
    }
    @GetMapping("get_collection")
    @Operation(summary = "获取某一分类下收藏的文章")

    Result<PageResult> getCollection(@RequestParam("userId") Integer userId,
                                     @RequestParam("domain") String domain,
                                     @RequestParam("page") Integer page,
                                     @RequestParam("pageSize") Integer pageSize){
        PageResult pageResult=userService.getCollection(userId,domain,page,pageSize);
        return Result.success(pageResult);
    }
    @DeleteMapping("/delete_folder")
    @Operation(summary = "删除某一分类的全部收藏")

    Result deleteFolder(@RequestParam("userId") Integer userId,@RequestParam("domain") String domain) throws Exception {
        userService.deleteFolder(userId,domain);
        return Result.success();
    }
    @PostMapping("/add_folder")
    @Operation(summary = "增加一个收藏分类")

    Result addFolder(@RequestParam("userId") Integer userId,@RequestParam("newDomain") String newDomain) throws Exception {
        userService.addFolder(userId,newDomain);
        return Result.success();

    }
    @DeleteMapping("/cancel_collected")
    @Operation(summary = "取消收藏一篇文献")

    Result cancelCollected(@RequestParam("id") Integer id){
        userService.cancelCollected(id);
        return Result.success();
    }
    @PostMapping("/add_collection")
    @Operation(summary = "收藏一篇文献")

    Result addCollection(@RequestBody Collection collection){
        userService.addCollection(collection);
        return Result.success();
    }
}
