package com.example.information_retrieval.sevice.Impl;

import com.example.information_retrieval.dataBasePojo.UploadRecord;
import com.example.information_retrieval.dataBasePojo.UserVo;
import com.example.information_retrieval.mapper.AdminMapper;
import com.example.information_retrieval.mapper.UploadRecordMapper;
import com.example.information_retrieval.result.PageResult;
import com.example.information_retrieval.sevice.AdminService;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdminServiceImpl implements AdminService {
    @Autowired
    AdminMapper adminMapper;
    @Autowired
    UploadRecordMapper uploadRecordMapper;

    @Override
    public PageResult getUserInfo(Integer page, Integer pageSize) {
        PageHelper.startPage(page,pageSize);
        Page<UserVo> userVos=adminMapper.getUserInfo(page,pageSize);
        return new PageResult(userVos.getTotal(),userVos.getResult());
    }

    @Override
    public PageResult getUploadRecord(Integer page, Integer pageSize) {
        PageHelper.startPage(page,pageSize);
        Page<UploadRecord> uploadRecords=uploadRecordMapper.getAllUploadRecord();
        return new PageResult(uploadRecords.getTotal(),uploadRecords.getResult());
    }

    @Override
    public void changeUploadRecordState(UploadRecord uploadRecord) {
        uploadRecordMapper.update(uploadRecord);
    }

    @Override
    public void deleteUploadRecord(Integer id) {
        uploadRecordMapper.deleteById(id);
    }
}
