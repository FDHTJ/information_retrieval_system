package com.example.information_retrieval.sevice.Impl;

import com.example.information_retrieval.sevice.RedisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.concurrent.TimeUnit;

@Service
public class RedisServiceImpl implements RedisService {
    @Autowired
    RedisTemplate<String,Object> redisTemplatel;


    @Override
    public void setVertificationCode(String key, String value) {
        redisTemplatel.opsForValue().set(key,value,5, TimeUnit.MINUTES);
    }

    @Override
    public String getVertificationCode(String key) throws Exception {
        Object value=redisTemplatel.opsForValue().get(key);
        if(value==null){
            throw new Exception("Email is wrong ! Or the code has expired! ");
        }else{
            return value.toString();
        }
    }

}
