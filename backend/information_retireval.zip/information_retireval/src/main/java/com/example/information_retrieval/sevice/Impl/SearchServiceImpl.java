package com.example.information_retrieval.sevice.Impl;
import com.example.information_retrieval.pojo.Article;
import com.example.information_retrieval.pojo.ArticleData;
import com.example.information_retrieval.sevice.SearchService;
import com.example.information_retrieval.utills.PorterStremAnalyzer;
import com.google.gson.Gson;
import org.apache.lucene.analysis.core.KeywordAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.Term;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.*;
import org.apache.lucene.search.highlight.Highlighter;
import org.apache.lucene.search.highlight.InvalidTokenOffsetsException;
import org.apache.lucene.search.highlight.QueryScorer;
import org.apache.lucene.search.highlight.SimpleHTMLFormatter;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.*;

@Service
public class SearchServiceImpl implements SearchService {
    private  String wildcardIndexDir="D:\\infomation_retrieval\\information_retireval\\src\\main\\resources\\indexes\\newIndexDirAll";
    private String indexDir="D:\\infomation_retrieval\\information_retireval\\newIndexAll";
    private String visitPath="http://localhost:8080/oriPDFs/";
    private String PDFpath="D:\\infomation_retrieval\\information_retireval\\src\\test\\java\\com\\example\\information_retrieval\\oriPDFSjson";

    public  static Integer ANY_TIME=0;
    public  static Integer SINCE2000=1;
    public  static Integer SINCE1900=2;
    @Override
    public List<ArticleData> getSearchResult(String field, String queryText,Integer currentPage,Integer dateChoice) throws InvalidTokenOffsetsException, IOException, ParseException {
        //首先判断查询的类型
        if(queryText==null || queryText.isEmpty()){
            throw new RuntimeException("查询不能为空");
        }
        Integer year=dateChoice.equals(SINCE2000)?2000:1900;
        int total=currentPage*10;
        int start=(currentPage-1)*10;
        List<ArticleData> result=new ArrayList<>();
        while(result.size()<10){
            List<ArticleData> temp=null;
            if (queryText.contains("*")||queryText.contains("?")){
                //说明是通配符查询
                temp= normalSearch(field,queryText,true,total);
            }
            if(queryText.length()>1&& queryText.charAt(0)=='\"' &&queryText.charAt(queryText.length()-1)=='\"'){
                //说明是短语查询
                temp=normalSearch(field,queryText,false,total);
            }
            if(temp==null){
                temp=normalSearch(field,queryText,true,total);
            }
            result.clear();

            for(int i=start;i<temp.size();i++){
                if(!dateChoice.equals(ANY_TIME) ){
                    //说明需要筛选日期
                    if(temp.get(i).getDate().isEmpty()){
                        //说明本身没有日期
                        result.add(temp.get(i));
                    }else{
                        String[] split = temp.get(i).getDate().split(" ");
                        String date=split[split.length-1];
                        try{
                            if(Integer.parseInt(date)>year){
                                result.add(temp.get(i));
                            }
                        }catch (Exception e){
                            continue;
                        }
                    }
                }else{
                    result.add(temp.get(i));
                }
                if(result.size()>=10)break;
            }
            if(temp.size()<total){
                //无论如何都要返回，因为已经没有了
                return result;
            }
            total+=10;
        }
        return result;
    }

    @Override
    public List<String> getSuggest(String field, String queryText) throws InvalidTokenOffsetsException, IOException, ParseException {

        return getStrings(field,queryText);
    }

    @Override
    public List<ArticleData> getRandomLook() throws FileNotFoundException {
        List<ArticleData> res=new ArrayList<>();
        while(res.size()<3){
            File[] files=new File(PDFpath).listFiles();
            Gson gson=new Gson();
            int i=2962;
            assert files != null;
            for(File f:files){
                int t=(int) (Math.random()*i);
                if(t==0) {
                    Article article = gson.fromJson(new FileReader(f.getAbsolutePath()), Article.class);
                    ArticleData articleData = new ArticleData();
                    if(article.getTitle()==null||article.getTitle().isEmpty()){
                        continue;
                    }
                    articleData.setDate(article.getDate());
                    articleData.setTitle(article.getTitle());
                    articleData.setWriters(String.join(" ; ", article.getWriters()));
                    articleData.setFileName(visitPath + article.getFileName().split("xml")[0] + "pdf");
                    articleData.setAddresses(String.join(" ; ", article.getAddresses()));
                    articleData.setKeywords(String.join(" ; ", article.getKeywords()));
                    articleData.setOrgNames(String.join(" ; ", article.getOrgNames()));
                    articleData.setDigest(article.getDigest());
                    res.add(articleData);
                    if(res.size()>=3)break;
                }
                i--;
            }

        }
        return res;
    }

    List<String> getStrings(String field, String queryText) throws IOException, ParseException, InvalidTokenOffsetsException {
        List<String> result=new ArrayList<>();
        Directory directory= FSDirectory.open(Paths.get(indexDir));
        PorterStremAnalyzer porterStremAnalyzer=new PorterStremAnalyzer(Collections.emptySet());
        IndexReader reader= DirectoryReader.open(directory);
        IndexSearcher indexSearcher=new IndexSearcher(reader);
        QueryParser parser=new QueryParser(field,porterStremAnalyzer);
        //PhraseQuery phraseQuery=
        if(queryText.contains("\"")){
            queryText=queryText.replace("\"","");
        }
        if(queryText.isEmpty())return result;
        Query query= parser.parse(queryText);
        SimpleHTMLFormatter formatter=new SimpleHTMLFormatter("<b style=\"color:red; padding-right:7px;padding-left:7px\">","</b>");
        Highlighter highlighter=new Highlighter(formatter,new QueryScorer(query));
        Set<String> res=new HashSet<>();
        TopDocs topDocs=indexSearcher.search(query,50);

        for(ScoreDoc scoreDoc:topDocs.scoreDocs){
            Document doc=indexSearcher.doc(scoreDoc.doc);
            String content=doc.get(field);
            String highlightText=highlighter.getBestFragment(new PorterStremAnalyzer(Collections.emptySet()),Article.WRITERS,content);
            if(highlightText==null){
                continue;
            }
            String[] split = highlightText.split("<b style=\"color:red; padding-right:7px;padding-left:7px\">");
            for(String word:split){
                if(word.contains("</b>")){
                    String temp=word.replace("</b>","");
                    res.add(temp);
                }
            }
        }
        reader.close();
        directory.close();
        for(String s:res){
            result.add(s);
        }
        return result;
    }
     List<ArticleData> normalSearch(String field,String queryText,Boolean isNormal,int total) throws IOException, InvalidTokenOffsetsException, ParseException {

        List<ArticleData> result=new ArrayList<>();
        Directory directory= FSDirectory.open(Paths.get(indexDir));
        PorterStremAnalyzer porterStremAnalyzer=new PorterStremAnalyzer(Collections.emptySet());
        IndexReader reader= DirectoryReader.open(directory);
        IndexSearcher indexSearcher=new IndexSearcher(reader);
        QueryParser parser=new QueryParser(field,porterStremAnalyzer);
        //PhraseQuery phraseQuery=
        Query query=isNormal ? parser.parse(queryText):parser.createPhraseQuery(field,queryText);
        //设置高亮器
        SimpleHTMLFormatter formatter=new SimpleHTMLFormatter("<b style=\"color:red; padding-right:7px;padding-left:7px\">","</b>");
        Highlighter highlighter=new Highlighter(formatter,new QueryScorer(query));
        TopDocs topDocs=indexSearcher.search(query,total);
        for(ScoreDoc scoreDoc:topDocs.scoreDocs){
            Document doc=indexSearcher.doc(scoreDoc.doc);
            String content=doc.get(field);
            String highlightText=highlighter.getBestFragment(new PorterStremAnalyzer(Collections.emptySet()),field,content);
            result.add(getArticleData(doc,highlightText,field));
            //String highlightText=highlighter.getBestFragment(new PorterStremAnalyzer(Collections.emptySet()),Article.WRITERS,content);
        }
        reader.close();
        directory.close();
        return result;
    }
    List<ArticleData> wildcardSearch(String field,String queryText,int total) throws IOException, InvalidTokenOffsetsException {
        List<ArticleData> result=new ArrayList<>();
        Directory directory= FSDirectory.open(Paths.get(wildcardIndexDir));
        IndexReader reader= DirectoryReader.open(directory);
        IndexSearcher indexSearcher=new IndexSearcher(reader);
        //PhraseQuery phraseQuery=
        Query query=new WildcardQuery(new Term(field,queryText));//parser.createMinShouldMatchQuery() //parser.parse("Gary");//    parser.createPhraseQuery("title","Multidisciplinary Using",1);//
        //设置高亮器
        SimpleHTMLFormatter formatter=new SimpleHTMLFormatter("<b style=\"color:red; padding-right:7px;padding-left:7px\">","</b>");
        Highlighter highlighter=new Highlighter(formatter,new QueryScorer(query));
        TopDocs topDocs=indexSearcher.search(query,total);
        for(ScoreDoc scoreDoc:topDocs.scoreDocs){
            Document doc=indexSearcher.doc(scoreDoc.doc);
            String content=doc.get(field).replace('\t',' ');
            String highlightText=null;
            if(! field.equals("fulltext")){
                highlightText=highlighter.getBestFragment(new KeywordAnalyzer(),field,content);
            }
            result.add(getArticleData(doc,highlightText,field));
            //String highlightText=highlighter.getBestFragment(new PorterStremAnalyzer(Collections.emptySet()),Article.WRITERS,content);
        }
        reader.close();
        directory.close();
        return result;
    }
    ArticleData getArticleData(Document doc,String highlightText,String field){
        ArticleData articleData=new ArticleData();
        articleData.setFileName(visitPath+doc.get(Article.FILE_NAME));
        articleData.setDigest(doc.get(Article.DIGEST));
        articleData.setTitle(doc.get(Article.TITLE));
        articleData.setDate(doc.get(Article.DATE));
        articleData.setKeywords( doc.get(Article.KEYWORDS).replace('\t',' '));
        articleData.setOrgNames(doc.get(Article.ORGNAMES).replace('\t',' '));
        articleData.setAddresses(doc.get(Article.ADDRESSES).replace('\t',' '));
        articleData.setWriters(doc.get(Article.WRITERS).replace('\t',' '));
        if(field.equals(Article.DIGEST)){
            String[] split = highlightText.split("<b style=\"color:red; padding-right:7px;padding-left:7px\">");
            List<String> words=new ArrayList<>();
            for(String s:split){
                if(s.contains("</b>")){
                    words.add(s.replace("</b>",""));
                }
            }
            String s=articleData.getDigest();
            for(String word:words){
                s=s.replace(word,"<b style=\"color:red; padding-right:7px;padding-left:7px\">"+word+"</b>");
            }
            articleData.setDigest(s);
            return articleData;
        }
        switch (field){
            case Article.TITLE -> articleData.setTitle(highlightText);
            case Article.ADDRESSES -> articleData.setAddresses(highlightText);
            case Article.WRITERS -> articleData.setWriters(highlightText);
            case Article.KEYWORDS -> articleData.setKeywords(highlightText);
            case Article.ORGNAMES -> articleData.setOrgNames(highlightText);
        }
        return articleData;
    }
}
