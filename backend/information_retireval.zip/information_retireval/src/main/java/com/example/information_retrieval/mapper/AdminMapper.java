package com.example.information_retrieval.mapper;

import com.example.information_retrieval.dataBasePojo.UserVo;
import com.github.pagehelper.Page;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface AdminMapper {
    @Select("select * from thesis_retrieval.user")
    Page<UserVo> getUserInfo(Integer page, Integer pageSize);
}
