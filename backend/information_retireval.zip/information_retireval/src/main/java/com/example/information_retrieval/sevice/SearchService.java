package com.example.information_retrieval.sevice;

import com.example.information_retrieval.pojo.ArticleData;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.search.highlight.InvalidTokenOffsetsException;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

public interface SearchService {
    List<ArticleData> getSearchResult(String field, String queryText,Integer currentPage,Integer dateChoice) throws InvalidTokenOffsetsException, IOException, ParseException;

    List<String> getSuggest(String field, String queryText) throws InvalidTokenOffsetsException, IOException, ParseException;

    List<ArticleData> getRandomLook() throws FileNotFoundException;
}
