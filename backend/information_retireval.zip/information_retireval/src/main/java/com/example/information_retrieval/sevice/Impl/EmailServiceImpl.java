package com.example.information_retrieval.sevice.Impl;

import com.example.information_retrieval.dataBasePojo.User;
import com.example.information_retrieval.mapper.UserMapper;
import com.example.information_retrieval.sevice.EmailService;
import com.example.information_retrieval.sevice.RedisService;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmailServiceImpl implements EmailService {
    @Autowired
    private JavaMailSender mailSender;
    @Autowired
    private RedisService redisService;
    @Autowired
    private UserMapper userMapper;
    @Override
    public void sendVerificationEmail(String target, String text, String subject, Boolean isRegister) throws Exception {
        List<User> sameEmailUsers=userMapper.getByEmail(target);
        if(isRegister){
            //验证是否使用过
            if(sameEmailUsers!=null &&!sameEmailUsers.isEmpty()){
                throw  new Exception("Email has been used !");
            }
        }
        else{
            if(sameEmailUsers==null||sameEmailUsers.isEmpty()){
                throw new Exception("The account is not existed !");
            }
        }
        SimpleMailMessage message=new SimpleMailMessage();
        // 生成随机验证码
        String code = RandomStringUtils.randomNumeric(6);
        message.setFrom("15171937985@163.com");
        message.setTo(target);
        message.setSubject(subject);
        message.setText("您的验证码为： "+code+"\n仅在五分钟内有效");
        try {
            mailSender.send(message);
        }
        catch (Exception e){
            throw new Exception("Failed to send email ,Please check email address !");
        }
        //将验证码存到redis数据库中
        redisService.setVertificationCode(target,code);
    }


}
