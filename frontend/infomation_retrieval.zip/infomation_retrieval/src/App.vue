<script setup>
</script>

<template>
  <Transition name="el-fade-in-linear" >
    <router-view ></router-view>
  </Transition>

</template>

<style scoped>
.el-fade-in-linear-enter-active {
  transition: opacity 1s; /* 将动画持续时间改为 1 秒 */
}
</style>