import {createMemoryHistory,createRouter} from 'vue-router'
import home from '@/components/home.vue';
import search from '@/components/search.vue';
import details from '@/components/details.vue';
import show from '@/components/user/show.vue';
const routes=[
    {
        path:'/',
        component:home
    },
    {
        path:'/searchResult',
        component:search
    },
    {
        path:'/details',
        component:details
    },
    {
        path:'/show',
        component:show
    }
    
]
const router=createRouter({
    history:createMemoryHistory(),
    routes,
})
export default router;