<template>
    <div class="general-frame">
        <button class="button-style" @click="back"> Back </button>
        <button class="button-style" @click="checkPDF">View PDF</button>
        <button class="button-style" @click="openCollectDialog">Collect PDF</button>
        <el-dialog
            v-model="collectDialog"
            width="500"
            align-center
        >
            <template #title>
                <div style="text-align: center; width: 100%;">Collect</div>
            </template>
            <!-- 单选框 -->
            <el-radio-group v-model="selectedOption" style="margin-bottom: 10px;">
            <el-radio v-for="(option, index) in options" :key="index" :label="option">{{ option }}</el-radio>
            </el-radio-group>

            <!-- 添加新选项输入框 -->
            <div style="display: flex;">
                <el-input
                    v-model="newOption"
                    placeholder="Add new category"
                    @keyup.enter="addOption"
                />
                <el-button @click="addOption" type="primary">Add Category</el-button>
            </div>

            <template #footer>
            <div class="dialog-footer">
                <el-button @click="collectDialog = false">Cancel</el-button>
                <el-button type="primary" @click="confirmCollection">
                Confirm
                </el-button>
            </div>
            </template>
        </el-dialog>
        <p class="title" v-html="title"></p>
        <p class="writers" v-html="writers"></p>
        <div class="others">
            <div v-for="(value,index) of filteredEntries" style="display: flex; justify-content: flex-start; margin-bottom: 10px;">
                <div style="width: 60px; font-weight: bolder;">{{ value[0] }}：</div>
                <div style="margin-left: 50px;" v-html="value[1]"></div>
            </div>
            <!-- <div style="display: flex; justify-content: flex-start; margin-bottom: 10px;">
                <div style="margin-right: 38px; font-weight: bolder;">Digest：</div>
                <div>内容</div>
            </div>
            <div style="display: flex; justify-content: flex-start; margin-bottom: 10px;">
                <div style="margin-right: 12px; font-weight: bolder;">Keywords：</div>
                <div>内容</div>
            </div>
            <div style="display: flex; justify-content: flex-start; margin-bottom: 10px;">
                <div style="margin-right: -1.6px; font-weight: bolder;">ORGNames：</div>
                <div>内容</div>
            </div>
            <div style="display: flex; justify-content: flex-start; margin-bottom: 10px;">
                <div style="margin-right: 25px; font-weight: bolder;">Address：</div>
                <div>内容</div>
            </div> -->
        </div>
    </div>
</template>

<script scope setup>
import { ref ,onMounted} from 'vue'
import { useRoute ,useRouter} from 'vue-router/dist/vue-router';
import { useStore } from 'vuex';
import { ElMessage,ElLoading } from 'element-plus';
import axios from 'axios';
let loadingInstance = null;
const startLoading = () => {
  loadingInstance = ElLoading.service({
    lock: true,
    text: '加载中...',
    background: 'rgba(185, 180, 180, 0.5)'
  });
};
const endLoading = () => {
  if (loadingInstance) {
    loadingInstance.close();
  }
};
const route=useRoute();
const router =useRouter();
const store =useStore();
console.log(route.query.article);
const article=(JSON.parse( route.query.article.toString()));
const currentPage=ref(route.query.currentPage);
const dateChoice=ref(route.query.dateChoice);
const queryText=ref(route.query.queryText);
const field=ref(route.query.field);
const filteredEntries = Object.entries(article)
  .filter(([key, value]) => key !== "fileName" &&key!="title" &&key!="writers");
const title=ref(article['title']);
console.log(title.value);
const writers=ref(article['writers']);
const  checkPDF=()=> {
            window.open(article['fileName'],"_blank");
        }
 const  back=()=> {
            if(currentPage.value=="-1"){
                router.go(-1);
            }else{
                //需要回到检索页
                console.log(currentPage.value);
                console.log(dateChoice.value);
                console.log(queryText.value);
                console.log(field.value);

                router.push({
                    path:"/searchResult",
                    query:{
                    currentPage:currentPage.value,
                    dateChoice:dateChoice.value,
                    queryText:queryText.value,
                    field:field.value
                }});

                
            }}

const collectDialog = ref(false);
const options = ref([]) // 初始选项
const selectedOption = ref('all') // 记录选中的选项
const newOption = ref('') // 新添加的选项
const getAllFolder=async()=>{
  startLoading();
      await axios.get(store.state.requestPath+"/user/get_all_folder",{
        headers:{
          token:store.state.token
        },
        params:{
          userId:store.state.userId
        }
      }).then(response=>{
        options.value=response.data.data;
      }).catch(()=>{
        ElMessage.error("There is something wrong ! Please try again later !");
      });
      endLoading();
}
onMounted(()=>{
    if(store.state.isLoggedIn){
        getAllFolder();
    }
})
// 打开对话框
const openCollectDialog = () => {
    if(!store.state.isLoggedIn){
        ElMessage.warning("You have to login first !");
        return ;
    }
   
        getAllFolder();
    
    collectDialog.value = true;
}
// 添加新分类
const addOption =async () => {
    // 检查名称是否为空
    if (newOption.value.trim() === '') {
        ElMessage.error("The new category's name cannot be empty");
        newOption.value = '';
    }else {
        // 检查名称是否已经存在
        const existingOption = options.value.find(option => option === newOption.value.trim());
        if (existingOption) {
            ElMessage.error(`the category '${newOption.value}' has been existed`)
        } else {
            startLoading();
    await axios.post(store.state.requestPath+"/user/add_folder",null,{
      headers:{
        token:store.state.token
      },
      params:{
        userId:store.state.userId,
        newDomain:newOption.value
      }
    }).then(async(response)=>{
      if(response.data.code !=1){
        ElMessage.error(response.data.msg);
      }else{
        ElMessage.success("Successful !");
        await getAllFolder();
      }
    }).catch(()=>{
      ElMessage.error("There is something wrong ! Please try again later !");
    });
    dialogVisible.value = false;
    newTabLabel.value = '';
    endLoading();
        }
        newOption.value = '';
    }
}
// 确认收藏
const confirmCollection =async () => {
    startLoading();
    console.log(title.value);
    await axios.post(store.state.requestPath+"/user/add_collection",{
        userId:store.state.userId,
        title:title.value,
        domain:selectedOption.value
    },{
        headers:{
            token:store.state.token
        }
    }).then(response=>{
        ElMessage.success("Collect the thesis successfully!");
    }).catch(()=>{
        ElMessage.error("There is something wrong !Please try again later !");
    })
    endLoading();
    collectDialog.value = false;
}

</script>

<style scoped>
.general-frame {
    width: 90%;
    background-color: rgba(255, 255, 255, 0.9);
    border-radius: 15px;
    padding: 60px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5); /* 阴影效果 */
}
.button-style {
    padding: 8px; 
    background-color: #3dc9db;
    border: none;
    margin-right: 10px;
    border-radius: 5px;
    cursor: pointer;
    transition: box-shadow 0.4s ease; 
}
.button-style:active {
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.5); /* 点击时的阴影效果 */
    background-color: #2b8591;
}
.title {
    font-weight: bolder;
    font-size: 20px;
    text-align: center;
}
.writers {
    align-items: center;
    color: #36a8b8;
    font-size: 18px;
    text-align: center;
    margin-bottom: 20px;
}
.others {
    padding-left: 20px;
    font-size: 16px;
}

</style>