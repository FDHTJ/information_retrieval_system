<template>
    <div class="avatar-container" trigger="click" v-if="getLoginState()">
        <el-dropdown @command="handleOption">
            <img :src="userImage()" 
            alt="image"
                style="width: 38px; height: 38px; border-radius: 20px; position: absolute; top: 1px;">
            <template #dropdown>
                <el-dropdown-menu slot="dropdown">
                    <el-dropdown-item command="Register">Register</el-dropdown-item>
                    <el-dropdown-item command='Log In'>Log In</el-dropdown-item>
                </el-dropdown-menu>
            </template>
        </el-dropdown>
    </div>
    <div class="avatar-container" trigger="click" v-if="!getLoginState()">
        <div >
            <img @click="toUserInfo" 
            :src="userImage()" 
            alt="image"
                style="width: 38px; height: 38px; border-radius: 20px; position: absolute; top: 1px;">
        </div>
    </div>

    <el-dialog class="dialog" v-model="registerDialog" width="500" align-center @close="resetForm">
        <template #title>
            <div style="text-align: center; width: 100%; color: black;">Register</div>
        </template>
        <!-- 注册表单 -->
        <el-form :rules="registerRules" :model="registerForm" label-width="auto" style="max-width: 500px;">
            <el-form-item label="Username" prop="registerName">
                <el-input v-model="registerForm.registerName" placeholder="Enter username" />
            </el-form-item>
            <el-form-item label="Password" prop="registerPwd">
                <el-input v-model="registerForm.registerPwd" type="password" placeholder="Enter password" />
            </el-form-item>
            <el-form-item label="Email" prop="registerEmail">
                <el-input v-model="registerForm.registerEmail" placeholder="Enter email" />
            </el-form-item>
            <el-form-item label="Verification Code" prop="registerVerificationCode">
                <el-input v-model="registerForm.registerVerificationCode" placeholder="Enter verificationCode" />
            </el-form-item>
            <div style="display: flex; justify-content: flex-end;">
                <el-button :disabled="isCounting" type="primary" @click="sendRegisterVerificationCode">{{ isCounting ?
                    `${countdown} s` : 'Send Verification Code' }}</el-button>
            </div>
        </el-form>

        <template #footer>
            <div>
                <el-button @click="cancelSubmit">Cancel</el-button>
                <el-button type="primary" @click="onSubmit">Confirm</el-button>
            </div>
        </template>
    </el-dialog>

    <el-dialog class="dialog" v-model="dialogVisible" width="500" align-center @close="resetForm">
        <template #title>
            <div style="text-align: center; width: 100%; color: black;">{{ isResetPassword ? 'Reset Password' : (isForgotPassword ?
                'Forgot Password' : 'Log In') }}</div>
        </template>

        <!-- 登录表单 -->
        <el-form v-if="!isForgotPassword && !isResetPassword" :rules="rules" :model="form" label-width="auto"
            style="max-width: 500px;">
            <el-form-item label="Username" prop="name">
                <el-input v-model="form.name" placeholder="Enter username or email" />
            </el-form-item>
            <el-form-item label="Password" prop="pwd">
                <el-input v-model="form.pwd" type="password" placeholder="Enter password" />
            </el-form-item>
        </el-form>

        <!-- 忘记密码表单 -->
        <el-form v-if="isForgotPassword && !isResetPassword" :rules="forgetRules" :model="forgetForm" label-width="auto"
            style="max-width: 500px;">
            <el-form-item label="Email" prop="email">
                <el-input v-model="forgetForm.email" placeholder="Enter email" />
            </el-form-item>
            <el-form-item label="Verification Code" prop="verificationCode">
                <el-input v-model="forgetForm.verificationCode" placeholder="Enter verificationCode" />
            </el-form-item>
            <div style="display: flex; justify-content: flex-end;">
                <el-button :disabled="isCounting" type="primary" @click="sendVerificationCode">{{ isCounting ?
                    `${countdown}
                    s` : 'Send Verification Code' }}</el-button>
            </div>
        </el-form>

        <!-- 修改密码表单 -->
        <el-form v-if="isResetPassword" :rules="verifyRules" :model="verifyForm" label-width="auto"
            style="max-width: 500px;">
            <el-form-item label="New Password" prop="newPwd">
                <el-input v-model="verifyForm.newPwd" type="password" placeholder="Enter new password" />
            </el-form-item>
            <el-form-item label="Confirm Password" prop="confirmPwd">
                <el-input v-model="verifyForm.confirmPwd" type="password" placeholder="Enter new password again" />
            </el-form-item>
        </el-form>

        <!-- dialog底部 -->
        <template #footer>
            <div v-if="!isForgotPassword && !isResetPassword">
                <el-button type="primary" class="forget-password" @click="toggleForgetPassword">Forget
                    Password?</el-button>
                <div>
                    <el-button @click="cancelSubmit">Cancel</el-button>
                    <el-button type="primary" @click="onSubmit">Confirm</el-button>
                </div>
            </div>

            <div v-if="isForgotPassword && !isResetPassword">
                <el-button type="primary" @click="toggleForgetPassword">Back to Login</el-button>
                <el-button type="primary" @click="verifyCode">Verify Code</el-button>
            </div>

            <div v-if="isResetPassword">
                <el-button type="primary" @click="resetPassword">Change Password</el-button>
                <el-button @click="toggleForgetPassword">Back</el-button>
            </div>
        </template>
    </el-dialog>

</template>

<script  setup>
import { ref } from 'vue';
import { ElMessage } from 'element-plus';
import {useStore} from 'vuex';
import { useRouter } from 'vue-router';
import axios from 'axios';
const store=useStore();
const router=useRouter();
const getLoginState=()=>{
    console.log(!store.state.isLoggedIn);
    return !store.state.isLoggedIn;
}
const toUserInfo=()=>{
    router.push({
        path:"/show"
    });
}
const userImage=()=>{
    return store.state.userImage;
}
const handleOption = (command) => {
    
    if (command === 'Register') {
        console.log('Open Register Dialog');
        openRegisterDialog();
    } else if (command === 'Log In') {
        console.log('Open Login Dialog');
        openDialog();
    }
}

const registerDialog = ref(false);
// 打开注册表单
const openRegisterDialog = () => {
    registerDialog.value = true;
}

const registerForm = ref({
    registerName: '',
    registerPwd: '',
    registerEmail: '',
    registerVerificationCode: '',
})
// 注册表单验证规则
const registerRules = ref({
    registerName: [
        { required: true, message: 'Username cannot be empty', trigger: 'blur' }
    ],
    registerPwd: [
        { required: true, message: 'Password cannot be empty', trigger: 'blur' },
        {
            validator: (rule, value, callback) => {
                console.log("验证密码")
                console.log(form.value.pwd)
                console.log(value);
                if (!value) {
                    callback(new Error('Password cannot be empty'));
                } else if (value.length < 6) {
                    callback(new Error('Password must be at least 6 characters long'));
                } else if (!/^[a-zA-Z0-9_]+$/.test(value)) {
                    callback(new Error('Password must contain only letters, numbers, or underscores'));
                } else {
                    callback(); // 验证通过
                }
            },
            trigger: 'blur'
        }
    ],
    registerEmail: [
        { required: true, message: 'Email cannot be empty', trigger: 'blur' }
    ],
    registerVerificationCode: [
        { required: true, message: 'Please input the verification code', trigger: 'blur' },
        { len: 6, message: 'Verification code must be 6 digits', trigger: 'blur' }
    ],
})
// 注册发送验证码
const sendRegisterVerificationCode = async() => {
    if (!registerForm.value.registerEmail) {
        ElMessage.error('Please enter an email first');
        return;
    }

    // 触发邮箱验证
    
    try{
    const response=await axios.post(store.state.requestPath+"/user/email",null,{
    params:
    {
      target:registerForm.value.registerEmail,
      isRegister:true

    }});
    if(response.data.code!=1){
        ElMessage.error(response.data.msg);
        return;
    }
    }
    catch(e){
        console.log(e);
        
        ElMessage.error("There is something wrong !");
        return;
    }
        ElMessage.success("Email has been send !");
        isCounting.value = true;
        startCountdown();
    

}




// 登录表单验证规则
const form = ref({
    name: '',
    pwd: '',
})
const rules = ref({
    name: [
        { required: true, message: 'Username or email cannot be empty', trigger: 'blur' }
    ],
    pwd: [
        { required: true, message: 'Password cannot be empty', trigger: 'blur' },
        {
            validator: (rule, value, callback) => {
                console.log("验证密码")
                console.log(form.value.pwd)
                console.log(value);
                if (!value) {
                    callback(new Error('Password cannot be empty'));
                } else if (value.length < 6) {
                    callback(new Error('Password must be at least 6 characters long'));
                } else if (!/^[a-zA-Z0-9_]+$/.test(value)) {
                    callback(new Error('Password must contain only letters, numbers, or underscores'));
                } else {
                    callback(); // 验证通过
                }
            },
            trigger: 'blur'
        }
    ]
});

// 忘记密码验证规则
const forgetForm = ref({
    email: '',
    verificationCode: ''
})
const forgetRules = ref({
    email: [
        { required: true, message: 'Email cannot be empty', trigger: 'blur' }
    ],
    verificationCode: [
        { required: true, message: 'Please input the verification code', trigger: 'blur' },
        { len: 6, message: 'Verification code must be 6 digits', trigger: 'blur' }
    ],
})

// 校验确认密码是否一致
const validateConfirmPassword = (rule, value, callback) => {
    if (value === verifyForm.value.newPwd) {
        callback();
    } else {
        callback(new Error('The passwords do not match'));
    }
}

// 修改密码验证规则
const verifyForm = ref({
    newPwd: '',
    confirmPwd: ''
})
const verifyRules = ref({
    newPwd: [
        { required: true, message: 'Please input your new password', trigger: 'blur' },
        {
            validator: (rule, value, callback) => {
                console.log("验证密码")
                console.log(verifyForm.value.pwd)
                console.log(value);
                if (!value) {
                    callback(new Error('New password cannot be empty'));
                } else if (value.length < 6) {
                    callback(new Error('New password must be at least 6 characters long'));
                } else if (!/^[a-zA-Z0-9_]+$/.test(value)) {
                    callback(new Error('New password must contain only letters, numbers, or underscores'));
                } else {
                    callback(); // 验证通过
                }
            },
            trigger: 'blur'
        }
    ],
    confirmPwd: [
        { required: true, message: 'Please confirm your password', trigger: 'blur' },
        { validator: validateConfirmPassword, trigger: 'blur' }
    ]
})
const dialogVisible = ref(false);
const isForgotPassword = ref(false);
const isCounting = ref(false);
const countdown = ref(60);
const isResetPassword = ref(false); // 是否显示修改密码表单

const openDialog = () => {
    dialogVisible.value = true;
    console.log(dialogVisible.value)
}


// 切换到忘记密码页面
const toggleForgetPassword = () => {
    console.log(true);
    if (isForgotPassword.value) {
        isForgotPassword.value = false;
        isResetPassword.val = false;
    } else {
        isForgotPassword.value = true;
        isResetPassword.value = false;
    }
}

// 发送验证码
const sendVerificationCode = async() => {
    if (!forgetForm.value.email) {
        ElMessage.error('Please enter an email first');
        return;
    }
    try{
    const response=await axios.post(store.state.requestPath+"/user/email",null,{
    params:
    {
      target:forgetForm.value.email,
      isRegister:false
    }});
    if(response.data.code!=1){
        ElMessage.error(response.data.msg);
        return;
    }
    }
    catch(e){
        console.log(e);
        
        ElMessage.error("There is something wrong !");
        return;
    }
        ElMessage.success("Email has been send !");
        isCounting.value = true;
        startCountdown();

}
let interval = null;
// 启动倒计时
const startCountdown = () => {
    if (interval !== null) clearInterval(interval); // 如果存在上一个定时器，先清除它
    countdown.value = 60;
    isCounting.value = true;
    interval = setInterval(() => {
        countdown.value--;
        if (countdown.value === 0) {
            clearInterval(interval); // 停止倒计时
            isCounting.value = false; // 恢复按钮状态
            countdown.value = 60;
            interval = null; // 重置倒计时
        }
    }, 1000);
}
// 验证验证码并跳转到修改密码表单
const verifyCode = async () => {
    try {
        const response = await axios.post(store.state.requestPath + "/user/verify_code", null,
            {
                params:
                {
                    target: forgetForm.value.email,
                    verificationCode: forgetForm.value.verificationCode
                }
            });
        if (response.data.code != 1) {
            ElMessage.error(response.data.msg);
            return;
        }
    }
    catch (e) {
        console.log(e);
        ElMessage.error("There is something wrong !");
        return;
    }
    isForgotPassword.value = false;
    isResetPassword.value = true;
    
}

// 修改密码提交
const resetPassword = async() => {
    if (verifyForm.value.newPwd === verifyForm.value.confirmPwd) {
        try {
        const response = await axios.post(store.state.requestPath + "/user/change_password",
            {
               email:forgetForm.value.email,
               vertificationCode:forgetForm.value.verificationCode,
               password:verifyForm.value.newPwd
            });
        if (response.data.code != 1) {
            ElMessage.error(response.data.msg);
            return;
        }
    }
    catch (e) {
        console.log(e);
        ElMessage.error("There is something wrong !");
        return;
    }
        ElMessage({
            message: 'Password changed successfully!',
            type: 'success',
            duration: 1000, // 显示2秒
        });
        isForgotPassword.value = false;
        isResetPassword.value = false;
        
        // 这里在后端修改用户密码
    } else {
        ElMessage.error('Password change failed. Please try again.');
    }
}
// 重置表单内容
const resetForm = () => {
    registerForm.value = {
        registerName: '',
        registerPwd: '',
        registerEmail: '',
    };
    form.value = {
        name: '',
        pwd: '',
    };
    forgetForm.value = {
        email: '',
        verificationCode: ''
    };
    verifyForm.value = {
        newPwd: '',
        confirmPwd: '',
    }; // 清空所有表单字段
    isForgotPassword.value = false;
    isResetPassword.value = false;
    isCounting.value = false;
    countdown.value = 60;

}
// 提交表单
const onSubmit = async() => {
    // 保证所有信息填写完整
    if (registerDialog.value === true) {
        for (const [key, value] of Object.entries(registerForm.value)) {
            if (value == "") {
                ElMessage.error("Please fill out the form completely!");
                return;
            }
        }
        try{
            const response =await axios.post(store.state.requestPath+"/user/register",{
            userName:registerForm.value.registerName,
            password:registerForm.value.registerPwd,
            email:registerForm.value.registerEmail,
            vertificationCode:registerForm.value.registerVerificationCode,
        });
        if(response.data.code!=1){
            ElMessage.error(response.data.msg);
            return;
        }else{
            ElMessage.success("Register Successful!");
        }
        }catch{
            ElMessage.error("There is something wrong ,Please try again !");
            return;
        }
        
    }
    if (dialogVisible.value === true) {
        for (const [key, value] of Object.entries(form.value)) {
            if (value == "") {
                ElMessage.error("Please fill out the form completely!");
                return;
            }
        }
        try{
     
            const response=await axios.post(store.state.requestPath+"/user/login",null,{
                params:{
                    name:form.value.name,
                    password:form.value.pwd
                }
            });
            if(response.data.code!=1){
                ElMessage.error(response.data.msg);
                return ;
            }else{
                //说明登录成功了
                console.log(response);
                
                var userInfo={
                    userId:response.data.data.userId,
                    userName:response.data.data.userName,
                    email:response.data.data.email,
                    token:response.data.data.token,
                    isManager:response.data.data.isManager,
                    userImage:response.data.data.avatar,
                };
                store.dispatch("login",userInfo);
                ElMessage.success("Login Successfully!");
            }
        }catch(e){
            console.log(e);
            ElMessage.error("There is something wrong ,Please try again !");
            return ;
        }

    }
    dialogVisible.value = false;
    registerDialog.value = false;
    resetForm();
    // // 校验整个表单
    // if (valid) {
    //     ElMessage.success('Log in successfully!');
    //     // 在这里进行提交逻辑，如调用 API 提交表单数据
    // } else {
    //     ElMessage.error('Please fill out the form correctly');
    // }
    // console.log('Submitted:'); // 输出表单数据
}

// 取消提交
const cancelSubmit = () => {
    dialogVisible.value = false;
    registerDialog.value = false;
    resetForm();
}

</script>

<style scoped>
.avatar-container {
    position: absolute;
    top: 18px;
    left: 66.5%;
    cursor: pointer;
    border: none;
    padding: 0;
    display: inline-block;
    background: none;
    border-radius: 20px;
    width: 38px;
    height: 38px;
}

.avatar-container:hover {
    opacity: 0.8;
}

.el-dialog {
    background-image: url('https://img-baofun.zhhainiao.com/pcwallpaper_ugc_mobile/static/2e41bfb0411eef975388a77181a820c0.jpg?x-oss-process=image%2fresize%2cm_lfit%2cw_640%2ch_1138');
    /* 设置背景图片的位置和大小 */
    background-position: left center;
    background-size: 50% auto;
    /* 宽度设置为50%，高度自动 */

    /* 添加渐变效果 */
    background: linear-gradient(to right, rgba(255, 255, 255, 0), rgba(255, 255, 255, 1)), url('https://img-baofun.zhhainiao.com/pcwallpaper_ugc_mobile/static/2e41bfb0411eef975388a77181a820c0.jpg?x-oss-process=image%2fresize%2cm_lfit%2cw_640%2ch_1138');

    /* 设置渐变的开始和结束位置 */
    background-repeat: no-repeat;
    background-blend-mode: overlay;
    /* 混合模式，确保渐变和图片融合 */
}

.el-dialog__body {
    margin-top: 18px;
}

.forget-password {
    margin-top: 0px;
    margin-bottom: 10px;
    font-size: 12px;
    padding: 5px;
}

.el-dropdown-menu {
    z-index: 9999;
    /* 确保菜单在其他元素之上 */
}
</style>