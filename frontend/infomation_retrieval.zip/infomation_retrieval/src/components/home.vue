<template>
    <div class="background-container">
      <el-header class="header">
        <img :src="imageSrc" alt="描述文字" class="icon">
        <span class="title">Thesis Retrieval</span>
        <register></register>
        <span class="top-right" style="left: 70%;">User</span>
        <img :src="homePng" class="home" >
      <span class="top-right" style="left: 78.5%;">Home</span>
      <drawer/>
      <span class="top-right" style="left: 88%;">History</span>
      </el-header>
      <el-main class="main">
        <searchBucket/>
        <guessYouLike/>
      </el-main>
    </div>
  
  </template>
  
  <script>
import imageSrc from '@/assets/analysis256_24853.png';
import guessYouLike from './guessYouLike.vue';
import searchBucket from './searchBucket.vue';
import homePng from '@/assets/diagram-06_24511.png';
import historyPng from '@/assets/history.png';
import drawer from './drawer.vue';
import register from './register.vue';
export default {
  // 注册子文件
  components: {
    guessYouLike,
    searchBucket,
    drawer,
    register
  },
  name: 'home',
  data() {
    return {
      imageSrc,
      homePng,
      historyPng,
    }
  }
}
  </script>
  
  
  <style scoped>
  * {
    margin:0;
    padding: 0;
    box-sizing: border-box;
  }
  html, body {
    margin: 0; /* 移除页面的默认外边距 */
    padding: 0; /* 移除页面的默认内边距 */
    height: 100%; /* 设置高度为100% */
    width: 100%;
    overflow-x: hidden; /* 禁止水平滚动 */
  }
  .background-container {
    position: fixed; /* 使用 fixed 定位覆盖整个页面 */
    left: 0;
    top: 0;
    width: 100%; /* 宽度占满 */
    height: 100vh; /* 高度占满 */
    background-image: url('https://wallpaperm.cmcm.com/b314579174f4022e6f32e622a85fca4e.jpg'); /*设置背景图片 */
    background-size: cover; /* 背景图片覆盖整个容器
    background-position: center; /* 背景图片居中 */
    display: flex; /* 使用Flexbox布局 */
    flex-direction: column; /* 纵向排列 */
    justify-content: center; /* 垂直居中 */
    align-items: center; /* 水平居中 */
  }
  
  .header {
    background: linear-gradient(to top, rgba(255, 255, 255, 0), rgba(63, 63, 63, 0.8)); /* 从下到上渐变 */
    /* background-color: rgba(255, 255, 255, 0.7); 半透明背景色 */
    padding-top: 15px;
    text-align: left;
    width: 100%;
  }
  
  .main {
    color: black; /* 主内容文本颜色 */
    text-align: center;
    width: 100%;
    flex: 1; /* 主内容区域扩展以占满剩余空间 */
    box-sizing: border-box; /* 确保组件的宽度包含内边距和边框，防止超出设定宽度 */
  }
  
  .icon {
    position: absolute; /* 绝对定位 */
    top: 12px; /* 距离上边缘20px */
    left: 80px; /* 距离左边缘20px */
    width: 50px;
    height: 40px;
    margin-right: 10px; /* 图标与文字之间的间距 */
  }
  
  .title {
    position: absolute;
    top: 15px;
    left: 135px;
    font-size: 26px;
    color: #d6d4d4;
    font-weight: bold;
    font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
  }

  .top-right {
  position: absolute;
  top: 25px;
  font-size: 22px;
  color: #e7e5e5;
  font-weight: bold;
  font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
}
.home {
  height: 40px; 
  position: relative;
  left: 75%;
  cursor: pointer;
}
.home:hover {
  opacity: 0.8;
}
  </style>