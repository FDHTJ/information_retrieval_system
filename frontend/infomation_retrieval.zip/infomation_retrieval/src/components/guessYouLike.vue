<template>
    <div class="rounded-box">
        <div class="top">
            <p class="like">随便看看</p>
            <el-button class="change" @click="getRandomLook" type="primary" round>换一批</el-button>
        </div>
        <el-link v-for="(value,index) of all_data" class="recommend" @click="seeDetails(index)">{{index+1}}.{{value['title']}}</el-link>
    </div>
</template>

<script scoped setup>
import { ref } from 'vue'
import axios from 'axios'
import { ElText ,ElLoading, ElMessage} from 'element-plus';
import { useRoute,useRouter } from 'vue-router/dist/vue-router';
import { useStore } from 'vuex';
const store =useStore();
const all_data=ref([]);
const router=useRouter();
let loadingInstance = null;
const startLoading = () => {
  loadingInstance = ElLoading.service({
    lock: true,
    text: '加载中...',
    background: 'rgba(185, 180, 180, 0.5)'
  });
};
const endLoading = () => {
  if (loadingInstance) {
    loadingInstance.close();
  }
};
const getRandomLook=async()=>{
    try{
        startLoading();
        const response = await axios.get(store.state.requestPath+"/search/random_look");
        all_data.value=response.data.data;
    }catch(error){
        ElMessage.error("There is something wrong ! Please try again !");
        
        console.log("错误");
    }
    finally{
        endLoading();
    }
}
getRandomLook();
const seeDetails=(index)=>{
    var dic={};
    for(const [key,value] of Object.entries(all_data.value[index])){
        if(value==""){
            dic[key]="unknown";
        }else{
            dic[key]=value;
        }
    }
    if(store.state.isLoggedIn&&dic["title"] !="unknown"){
    try{
    axios.post(store.state.requestPath+"/user/add_history",{
      userId:store.state.userId,
      title:dic['title'],
    },{
        headers:
      {
        token:`${store.state.token}`
      },
    });
  }catch{
  }
  }
    router.push({
        path:"/details",
        query:{
        article: JSON.stringify(dic),
        currentPage:-1,
        dateChoice:-1,
        queryText:"",
        field:"",
      }
    });
    
}
</script>

<style scoped>
.like {
    display: flex;
    align-items: center;
    /* 水平居中 */
    padding-bottom: 0px;
    font-size: 20px;
    color: #5e5b5b;
    font-weight: bold;
    flex: 1;
}

.rounded-box {
    position: relative;
    background-color: rgba(255, 255, 255, 0.8);
    /* 背景色 */
    border-radius: 20px;
    /* 圆弧边框 */
    padding-top: 10px;
    padding-left: 20px;
    padding-right: 15px;
    margin: 100px auto 50px;
    /* 上下间距，左右自动居中 */
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
    /* 阴影效果 */
    display: flex;
    width: 70%;
    max-width: 695px;
    overflow: hidden;
    flex-direction: column;
    /* 设置为纵向排列 */
    align-items: flex-start;
    /* 元素靠左对齐，不居中 */
}

.top {
    display: flex;
    /* 使用 Flexbox */
    flex: 1;
    width: 100%;
    align-items: center;
    /* 垂直居中对齐 */
    margin-bottom: 10px;
    /* 给下方内容留出空间 */
    justify-content: space-between;
    /* 元素分散对齐，第一个元素靠左，最后一个元素靠右 */
}

.change {
    margin-bottom: 7px;
}

.recommend {
    margin-top: 20px;
    font-size: 16px;
    align-content: flex-start;
    text-align: left;
    margin-bottom: 20px;

}
</style>
