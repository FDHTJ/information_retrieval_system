<template>
  <el-button class="image-button" @click="handleHistory"></el-button>
  <el-drawer v-model="table" title="Historical records of the past week:" direction="rtl" size="45%">
    <el-empty  v-if="!hasHistory" :image-size="200" description="No History Record !" />
    <el-table :data="gridData" v-if="hasHistory">
      <el-table-column property="date" label="Datetime" width="170px" />
      <el-table-column  property="title" label="Title" >
        
      </el-table-column>
      <el-table-column align="right">
      <template #header>
        <el-button
          size="small"
          type="danger"
          @click="handleDeleteAll"
        >
          DeleteAll
        </el-button>
      </template>
      <template #default="scope">
        <el-button v-if="!isDetail" size="small" @click="handleView(scope.$index)">
          view
        </el-button>
        <el-button
          size="small"
          type="danger"
          @click="handleDelete(scope.$index)"
        >
          Delete
        </el-button>
      </template>
    </el-table-column>
    </el-table>
  </el-drawer>
</template>

<script lang="ts" setup>
import { ref } from 'vue'
import { ElDrawer, ElMessage,ElMessageBox } from 'element-plus'
import axios from 'axios';
import { useRouter,useRoute } from 'vue-router';
import { useStore } from 'vuex';
const table = ref(false);
const hasHistory=ref(false);
const isDetail=ref(false);
const gridData =ref([]);
const router=useRouter();
const route=useRoute();
const store = useStore();
if(route.path=="/details"){
    isDetail.value=true;
  }else{
    isDetail.value=false;
  }
const handleHistory=async()=>{
  if(!store.state.isLoggedIn){
    ElMessage.warning("You have to login first !");
    return;}
  try{
    const response=axios.get(store.state.requestPath+"/user/get_history",{
      headers:
      {
        token:`${store.state.token}`
      },
      params:{
      userId:store.state.userId
    }});
    gridData.value=(await response).data.data;
    if(gridData.value.length==0){
      hasHistory.value=false;
    }else{
      hasHistory.value=true;
    }
  }catch(e){
    console.log(e);
    
    ElMessage.error("There is something wrong ! Please try again !");
  }finally{
    table.value=true;
  }
}
const handleView=async(index)=>{
 
  console.log(index);
  console.log(gridData.value[index]['title']);
  
  try{
    const response=axios.get(store.state.requestPath+"/search/get_search_result",{
      params:{
        "field": "title",
        "queryText": gridData.value[index]['title'].replace(/[|{}|\[\]]/g,""),
        "currentPage":1,
        "dateChoice":0,
      }
    });
    var temp={};
    for(const[key,value] of Object.entries((await response).data.data[0])){
      if(value==""){
        temp[key]="unknown";
      }else{
        temp[key]=value;
      }
    }
    router.push({
        path:"/details",
        query:{
        article: JSON.stringify(temp),
        currentPage:-1,
        dateChoice:-1,
        queryText:"",
        field:"",
      }
    });
  }catch{
    ElMessage.error("There is something wrong ! Please try again !");
  }
}
const handleDelete=async(index)=>{
  ElMessageBox.confirm('Are you sure to delete it ?')
    .then(() => {
      console.log(index);
  var l=[]

  l.push(gridData.value[index]['id']);
  try{
    const r=axios.delete(store.state.requestPath+"/user/delete_history",{
      headers:
      {
        token:`${store.state.token}`
      },
    params:{
      historyIds:l.join(',')
    }
  });
  }catch{
    console.log('error');
  }finally{
    gridData.value.splice(index,1);
    if(gridData.value.length==0){
      hasHistory.value=false;
    }else{
      hasHistory.value=true;
    }
  }
  
  
    })
    .catch(() => {
      // catch error
      console.log("no");
    });
    return;
  
}
const handleDeleteAll=async()=>{
  ElMessageBox.confirm('Are you sure to delete it all ?')
    .then(() => {
      console.log("yes");
      var l=[];
  for(var i of gridData.value){
    l.push(i['id']);
  }
  try{
    axios.delete(store.state.requestPath+"/user/delete_history",{
      headers:
      {
        token:`${store.state.token}`
      },
    params:{
      historyIds:l.join(',')
    }
  });
  }catch{
    console.log('error');
  }finally{
 
   gridData.value=[];
   hasHistory.value=false;
  }

    })
    .catch(() => {
      // catch error
      console.log("no");
    });
    return;
  
}
</script>

<style scoped>
.image-button:hover {
  opacity: 0.8;
}

.image-button {
  position: absolute;
  top: 18px;
  left: 84.5%;
  cursor: pointer;
  background-image: url('src/assets/history.png');
  background-color: rgba(255, 255, 255, 0);
  background-size: cover;
  background-position: center;
  border: none;
  width: 40px;
  height: 40px;
}
</style>