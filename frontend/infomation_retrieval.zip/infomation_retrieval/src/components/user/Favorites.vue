<template>
  <div style="height: 80%">
  <h1 style="font-size: 20px;color: rgba(0,0,0,0.7);">Favorites</h1>
  <el-divider />
  <el-button type="primary" @click="showAddTabDialog" style="width: 100px;">add folder</el-button>
  <el-dialog title="add folder" v-model="dialogVisible" width="30%">
      <el-form>
        <el-form-item label="folder title">
          <el-input v-model="newTabLabel" placeholder="please input folder title"></el-input>
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="dialogVisible = false">cancel</el-button>
          <el-button type="primary" @click="addTab">confirm</el-button>
        </span>
      </template>
    </el-dialog>
    <el-tabs class="demo-tabs" v-model="activeTab" @tab-change="handleTabChange" @tab-remove="handleTabRemove" closable="true">
      <el-dialog
      title="attention"
      v-model="dialogVisible2"
      width="30%"
    >
      <span>Do you want to delete the favorites?</span>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="dialogVisible2 = false">cancel</el-button>
          <el-button type="primary" @click="confirmDelete">confirm</el-button>
        </span>
      </template>
    </el-dialog>
        <el-tab-pane v-for="folder in folders" :key="folder" :label="folder" :name="folder" >
      <!-- 显示收藏的论文 -->
      <el-empty description="No data !" v-if="papers.length==0"/>
        <div v-for="(paper,index) in papers" :key="paper.id" v-if="papers.length!=0">
          <el-row><el-link @click="viewDetails(index)" class="title" v-html="paper.title" ></el-link></el-row>
          <el-row type="flex" justify="end"><el-col>
            <el-button type="success" plain size="mini" @click="removePaper(index)"><el-icon><star/></el-icon>cancel</el-button>
          </el-col></el-row>
          <el-divider />
       </div>
    </el-tab-pane>
  </el-tabs>
  <el-pagination 
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      v-model:current-page="currentPage"
      v-model:page-size="pageSize"
      layout="total, prev, pager, next, jumper"
      :total="totalItems" />
</div>
</template>

<script setup>
import { ref, onMounted,computed,watch, useId } from 'vue';
import {Star,} from '@element-plus/icons-vue';
import {ElMessage,ElLoading} from 'element-plus';
import axios from 'axios';
import { Store, useStore } from 'vuex';
import { useRouter } from 'vue-router';
const router=useRouter()
let loadingInstance = null;
const startLoading = () => {
  loadingInstance = ElLoading.service({
    lock: true,
    text: '加载中...',
    background: 'rgba(185, 180, 180, 0.5)'
  });
};
const endLoading = () => {
  if (loadingInstance) {
    loadingInstance.close();
  }
};
const store=useStore();
const folders = ref([]);
const papers=ref([]);
const dialogVisible = ref(false); // 控制对话框的显示与隐藏
const dialogVisible2 = ref(false); // 控制对话框的显示与隐藏
const newTabLabel = ref(''); // 新标签页的标题

// 添加收藏夹弹出框
const showAddTabDialog = () => {
  dialogVisible.value = true;
};

// 添加文件夹
const addTab = async() => {
  if (newTabLabel.value) {
    startLoading();
    await axios.post(store.state.requestPath+"/user/add_folder",null,{
      headers:{
        token:store.state.token
      },
      params:{
        userId:store.state.userId,
        newDomain:newTabLabel.value
      }
    }).then(async(response)=>{
      if(response.data.code !=1){
        ElMessage.error(response.data.msg);
      }else{
        ElMessage.success("Successful !");
        await getAllFolder();
      }
    }).catch(()=>{
      ElMessage.error("There is something wrong ! Please try again later !");
    });
    dialogVisible.value = false;
    newTabLabel.value = '';
    endLoading();
  } else {
    ElMessage.warning('The input can not be empty !');
  }
};
const getAllFolder=async()=>{
  startLoading();
      await axios.get(store.state.requestPath+"/user/get_all_folder",{
        headers:{
          token:store.state.token
        },
        params:{
          userId:store.state.userId
        }
      }).then(response=>{
        folders.value=response.data.data;
        activeTab.value="all";
      }).catch(()=>{
        ElMessage.error("There is something wrong ! Please try again later !");
      });
      endLoading();
}
// 获取文件数据
onMounted(()=>{
  getAllFolder();
  fetchItems();
  
}
);


// 删除收藏夹
const handleTabRemove = (tabName) => {
      if(tabName=="all"){
        ElMessage.error("This folder can not be deleted !");
        return;
      }
      activeTab.value = tabName;
      dialogVisible2.value = true;
    };

const confirmDelete = async() => {
  startLoading();
  await axios.delete(store.state.requestPath+"/user/delete_folder",{
    headers:{
      token:store.state.token
    },
    params:{
      userId:store.state.userId,
      domain:activeTab.value
    }
  }).then(async(response)=>{
    if(response.data.code !=1){
      ElMessage.error(response.data.msg);
    }else{
      ElMessage.success("Successful !");
      await getAllFolder();
      activeTab.value="all";
      await fetchItems();
    }
  }).catch(()=>{
    ElMessage.error("There is something wrong ! Please try again later !");
  })
      endLoading();
      dialogVisible2.value = false;
      
};
// 分页组件
const activeTab = ref("all"); // 初始化
const currentPage = ref(1);
const pageSize = ref(10);

const handleTabChange = async(activeName) => {
  // activeTab.value = activeName;
  console.log('当前标签页的 id:', activeTab.value);
  currentPage.value = 1; // 切换标签页时重置当前页
  await fetchItems();
};
const viewDetails=async(index)=>{
  try{
    const response=axios.get(store.state.requestPath+"/search/get_search_result",{
      params:{
        "field": "title",
        "queryText": papers.value[index].title.replace(/[|{}|\[\]]/g,""),
        "currentPage":1,
        "dateChoice":0,
      }
    });
    console.log(response);
    var temp={};
    for(const[key,value] of Object.entries((await response).data.data[0])){
      if(value==""){
        temp[key]="unknown";
      }else{
        temp[key]=value.replace("<b style=\"color:red; padding-right:7px;padding-left:7px\">","").replace("</b>","");
      }
    }
    router.push({
        path:"/details",
        query:{
        article: JSON.stringify(temp),
        currentPage:-1,
        dateChoice:-1,
        queryText:"",
        field:"",
      }
    });
  }catch(e){
    console.log(e);
    ElMessage.error("There is something wrong ! Please try again !");
  }
}


const totalItems = ref(0);

const fetchItems=async ()=> {
  startLoading();
  await axios.get(store.state.requestPath+"/user/get_collection",{
    params:{
      userId:store.state.userId,
      domain:activeTab.value,
      page:currentPage.value,
      pageSize:pageSize.value
    },
    headers:{
      token:store.state.token
    }
  }).then(
    response=>{
    papers.value=response.data.data.records;
    totalItems.value=response.data.data.total;
    }
  ).catch(()=>{
    ElMessage.error('There is something wrong ! Please try again later !');
  });
  endLoading();
}

const handleSizeChange=async(newSize)=> {
  pageSize.value = newSize;
  currentPage.value = 1; // 切换每页条数时重置当前页
  await fetchItems();
}

const handleCurrentChange=async(newPage)=> {
  currentPage.value = newPage;
  await fetchItems();
  window.scrollTo(0, 0); // 页面滚回顶部
}
// 取消收藏
const removePaper = async (index) => {
  startLoading();
    await axios.delete(store.state.requestPath+"/user/cancel_collected",{
      headers:{
        token:store.state.token
      },
      params:{
        id:papers.value[index].id      
      }
    }).then(async(response)=>{
        if(response.data.code!=1){
          ElMessage.error(response.data.msg);
        }else{
          ElMessage.success("Successful !");
          await fetchItems();
        }
    }).catch(()=>{
      ElMessage.error("There is something wrong ! Please try again later !");
    })
  endLoading();
};

// 确保在组件挂载时初始化 activeTab 并加载数据


// 监听 activeTab 变化，重新加载数据
// watch(activeTab, () => {
//   currentPage.value = 1; // 切换文件夹时重置当前页
//   fetchItems();
// });

</script>

<style scoped>
.folder.title{
  font-size: 20px;
  font-weight: bold;
}
.title {
  color: #5555a2;
  font-size: 20px;
  font-weight: bold;
  margin-bottom: 10px;
  display:-webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 1; /* 限制为一行 */
  line-clamp: 1;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: normal; /* 允许换行 */
}
.el-pagination {
  position: absolute;
  bottom: 10px; /* 距离底部的距离 */
  left: 10px; /* 距离左侧的距离 */
}

</style>