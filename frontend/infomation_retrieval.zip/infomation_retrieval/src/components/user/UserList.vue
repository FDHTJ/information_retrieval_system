<template>
  <div style=" height: 100%;">
    <h1 style="font-size: 20px;color: rgba(0,0,0,0.7);">UserList</h1>
    <el-divider />
    <div v-for="user in users" :key="user.id">
        <el-descriptions :title="'User：'+user.userId.toString()" label-width="150px" border>
    <el-descriptions-item
      :rowspan="2"
      label="avatar"
      align="center"
    >
    <el-avatar :size="50" fit="fill" :src="user.avatar" class="avatar" />
    </el-descriptions-item>
    <el-descriptions-item label="username">{{user.userName}}</el-descriptions-item>
    <el-descriptions-item label="userId">{{user.userId}}</el-descriptions-item>
    <el-descriptions-item label="email">{{user.email}}</el-descriptions-item>
    <el-descriptions-item label="isManager">{{user.isManager ? "true":"false"}}</el-descriptions-item>
  </el-descriptions>
  <el-divider />
  </div>
  <el-pagination 
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      v-model:current-page="currentPage"
      v-model:page-size="pageSize"
      layout="total, prev, pager, next, jumper"
      :total="totalItems" />
</div>
</template>

<script setup>
import { ref, onMounted,computed } from 'vue';
import axios from 'axios';
import { useStore } from 'vuex';
import { ElMessage,ElLoading } from 'element-plus';
let loadingInstance = null;
const startLoading = () => {
  loadingInstance = ElLoading.service({
    lock: true,
    text: '加载中...',
    background: 'rgba(185, 180, 180, 0.5)'
  });
};
const endLoading = () => {
  if (loadingInstance) {
    loadingInstance.close();
  }
};
const store=useStore(); 
const users = ref([]);
users.value = [
  {
    userId: 1,
    avatar: 'https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png',
    userName: 'qwe',
    email: '123@qq.com',
    isManager: 0
  },
  {
    userId: 2,
    avatar: 'https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png',
    userName: 'qwe',
    email: '123@qq.com',
    isManager: 1
  }
];

// onMounted(async () => {
//   // 模拟从后端获取邮箱数据
//   try {
//     const response = await axios.get('https://jsonplaceholder.typicode.com/users');
//     all_data.value = response.data;
//   } catch (error) {
//     console.error('获取数据失败', error);
//   }
//   users = [];
//   for(let user in all_data.value){
//     users.value.push({
//       userId: user.id,
//       username: user.username,
//       avatarUrl: user.avatarUrl || 'https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png', // 默认头像
//       email: user.email,
//       password: user.password
//     });
//     }
// });

// 分页组件
const currentPage = ref(1);
const pageSize = ref(10);
const totalItems = ref(1);
const fetchItems=async()=> {
  startLoading();
  try{
    const response=await axios.get(store.state.requestPath+"/admin/get_user_info",{
      headers:{
        token:store.state.token
      }
      ,
      params:{
        page:currentPage.value,
        pageSize:pageSize.value
      }
    });
    users.value=response.data.data.records;
    totalItems.value=response.data.data.total;
  }catch(e){
    console.log(e);
    ElMessage.error("There is something wrong ! Please try again later!");
  }finally{
    endLoading();
  }
};
const handleSizeChange= async (newSize)=> {
  pageSize.value = newSize;
  await fetchItems();
};

const handleCurrentChange=async (newPage)=> {
 
  currentPage.value = newPage;
  await fetchItems();
  window.scrollTo(0,0);//页面滚回顶部
 
};
// 初始加载数据
onMounted(() => {
  fetchItems();
});
</script>

<style scoped>
.avatar {
  border-radius: 50%;
}
.el-pagination {
  position: relative;
  bottom: 5%; /* 距离底部的距离 */
  left: 10px; /* 距离左侧的距离 */
}
</style>