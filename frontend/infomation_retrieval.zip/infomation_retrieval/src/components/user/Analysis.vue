<template>
    <div>
      <h1 style="font-size: 20px;color: rgba(0,0,0,0.7);">Analysis Article</h1>
      <el-divider />
      <el-upload
      class="upload-demo"
      drag
      action="https://run.mocky.io/v3/9d059bf9-4660-45f2-925d-ce80ad6c4d15"
      :before-upload="beforeUpload"
      :http-request="uploadFile"
      multiple>
      <el-icon class="el-icon--upload"><upload-filled /></el-icon>
      <div class="el-upload__text">
        Drop file here or <em>click to upload</em>
      </div>
    </el-upload>
    </div>
  </template>
  
  <script setup>
  import { UploadFilled, } from '@element-plus/icons-vue';
  import { ElMessage,ElUpload, } from 'element-plus';
  import axios from 'axios';
  import { onMounted } from 'vue';
  import { useStore } from 'vuex';
  const store =useStore();
  const beforeUpload = (file) => {
    const isPDF = file.type === 'application/pdf';
    if (!isPDF) {
      ElMessage.error('只能上传 PDF 文件!');
    }
    return isPDF;
  };
  const uploadFile = (options) => {
    const formData = new FormData();
      // formData.append('filename', options.file.name); // 传递文件名
    formData.append('file', options.file);
  // 上传文件
    axios.post(store.state.requestPath+"/user/analysis", formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
        token:store.state.token
      }
    })
    .then(response => {
      ElMessage.success('文件上传成功!');
      console.log('Upload success:', response.data);
      // 从后端获得word文档

      // 下载生成的 Word 文件
      const res = response.data.data;
        if (res) {
          var blob = new Blob([res], { type: 'text/plain' });
            // 创建一个指向该Blob的URL
            var url = URL.createObjectURL(blob);
          const link = document.createElement('a');
          link.href=url
          link.download = options.file.name.replace('.pdf', '.doc');
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
        }
    })
    .catch(error => {
      ElMessage.error('文件上传失败!');
      console.error('Upload error:', error);
    });
  };

  </script>
  