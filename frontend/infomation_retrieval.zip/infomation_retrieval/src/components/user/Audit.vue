<template>
<div style="width: 100%;height: 80%;">
    <h1 style="font-size: 20px;color: rgba(0,0,0,0.7);">Audit List</h1>
    <el-divider />
    <el-dialog v-model="dialogTableVisible" title="select the state " width="800">
      <el-radio-group v-model="selectedRecord.state" size="large">
      <el-radio label="Wait for auditing " value="Wait for auditing " style="color: orange;"/>
      <el-radio label="Pass" value="Pass" style="color: green;"/>
      <el-radio label="Failed" value="Failed" style="color: red;"/>
    </el-radio-group>
    <template #footer>
      <div class="dialog-footer">
        <el-button @click="dialogFormVisible = false">Cancel</el-button>
        <el-button type="primary" @click="changeState()">
          Confirm
        </el-button>
      </div>
    </template>
  </el-dialog>
    <el-table :data="papers" border>
      <el-table-column property="uploadDate" label="Datetime"  />
      <el-table-column  property="fileName" label="File name"  />
      <el-table-column property="userId" label="Provider Id" ></el-table-column>
      <el-table-column  property="state" label="state" >
        <template #default="scope">
          <span :style="getStateStyle(scope.row.state)">{{ scope.row.state }}</span>
        </template>
      </el-table-column>
      <el-table-column width="300">
      <template #default="scope">
        
        <el-button  size="small" @click="handleView(scope.$index)">
          View
        </el-button>
        <el-button  size="small" @click="handleChangeState(scope.$index)">
          Change State
        </el-button>
        <el-button
          size="small"
          type="danger"
          @click="handleDelete(scope.$index)"
        >
          Delete
        </el-button>
      </template>
    </el-table-column>
    </el-table>
    <el-divider />
    <el-pagination 
      @size-change="handleSizeChange"
      @current-change="handleCurrentChange"
      v-model:current-page="currentPage"
      v-model:page-size="pageSize"
      layout="total, prev, pager, next, jumper"
      :total="totalItems" />
</div>


</template>

<script setup>
import { ref, onMounted} from 'vue';
import axios from 'axios';
import { useStore } from 'vuex';
import { ElLoading,ElMessage,ElMessageBox } from 'element-plus';
const store=useStore();
let loadingInstance = null;
const startLoading = () => {
  loadingInstance = ElLoading.service({
    lock: true,
    text: '加载中...',
    background: 'rgba(185, 180, 180, 0.5)'
  });
};
const endLoading = () => {
  if (loadingInstance) {
    loadingInstance.close();
  }
};
const papers = ref([]);
const dialogTableVisible=ref(false);
papers.value=[
{
    id:1,
    fileName: '论文1',
    state: 'https://example.com/paper1.pdf',
    userId:1,
    uploadDate:" ",

  }
];
// // 获取待审核论文列表
// onMounted(async () => {
//   try {
//     const response = await axios.get('/api/papers/pending');
//     papers.value = response.data;
//   } catch (error) {
//     console.error('Failed to fetch pending papers:', error);
//   }
// });
const selectedRecord=ref({ 
  id:1,
    fileName: '论文1',
    state: 'https://example.com/paper1.pdf',
    userId:1,
    uploadDate:" ",});
// 查看论文
const handleView = (index) => {
 window.open(store.state.requestPath+"/uploadFile/"+papers.value[index].fileName,'_blank'); 
};
const handleChangeState=(index)=>{
    dialogTableVisible.value=true;
    selectedRecord.value=papers.value[index];
}
const changeState=async ()=>{
    await axios.post(store.state.requestPath+"/admin/change_upload_record_state",{
      id:selectedRecord.value.id,
      state:selectedRecord.value.state
    },{
      headers:{
        token:store.state.token
      }
    }).then(response=>{
      if(response.data.code==1){
        ElMessage.success("Successful !");
      }
    })
    .catch(e=>{
      ElMessage.error("There is something wrong please try again later !");
    });
    dialogTableVisible.value=false;

}
const handleDelete=async(index)=>{
  ElMessageBox.confirm('Are you sure to delete it ?')
  .then(async() => {
  await axios.delete(store.state.requestPath+"/admin/delete_upload_record",{
      headers:{
        token:store.state.token
      },
      params:{
        id:papers.value[index].id
      }
    }).then(response=>{
      if(response.data.code==1){
        ElMessage.success("Successful !");
        fetchItems();
      }
    })
    .catch(e=>{
      ElMessage.error("There is something wrong please try again later !");
    });});
}
// 分页组件
const currentPage = ref(1);
const pageSize = ref(10);
const totalItems = ref(0);
const fetchItems=async()=> {
  startLoading();
  await axios.get(store.state.requestPath+"/admin/get_upload_record",{
    params:{
      page:currentPage.value,
      pageSize:pageSize.value
    },
    headers:{
      token:store.state.token
    }
  }).then(response=>{
    papers.value=response.data.data.records;
    totalItems.value=response.data.data.total;
  }).catch(e=>{
    ElMessage.error("There is something wrong !Please try again later !");
  })
  endLoading();
};
const handleSizeChange=(newSize)=> {
  pageSize.value = newSize;
  fetchItems();
};

const handleCurrentChange=(newPage)=> {
  currentPage.value = newPage;
  fetchItems();
  window.scrollTo(0,0);//页面滚回顶部
};
// 初始加载数据
onMounted(() => {
  fetchItems();
});
const getStateStyle = (state) => {
  if (state === 'Wait for auditing ') {
    return { color: 'orange' };
  } else if (state === 'Pass') {
    return { color: 'green' };
  }else if(state==='Failed'){
    return {color:'red'}
  }
  return {};
};
</script>

<style scoped>
.title {
  color: #5555a2;
  font-size: 20px;
  font-weight: bold;
  margin-bottom: 10px;
  display:-webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 1; /* 限制为一行 */
  line-clamp: 1;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: normal; /* 允许换行 */
}
.el-pagination {
  position: absolute;
  bottom: 10px; /* 距离底部的距离 */
  left: 10px; /* 距离左侧的距离 */
}
</style>