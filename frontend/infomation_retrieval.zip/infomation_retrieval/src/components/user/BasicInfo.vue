<template>
    <div style="height: 100%">
      <el-row >
        <h1 style="font-size: 20px;color: rgba(0,0,0,0.7);">Basic Info</h1>
        <el-button type="primary" style="margin-left: 80%; margin-top: 1.5%;" plain @click="handleLogout">log out</el-button>
      </el-row>
      

      <el-divider />
      <el-descriptions :column="1" label-width="150px" label-align="right" content-align="left" border>
        <el-descriptions-item align="center" style="background: none;">
          <el-avatar :size="100" fit="fill" :src="avatarUrl()" class="avatar" />
          <el-upload
            class="upload-demo"
            :action=uploadUrl()
            :data=data
            :headers=headers
            :show-file-list="false"
            @success="handleAvatarSuccess"
            :before-upload="beforeUpload"
          >
            <el-button type="primary">change avatar</el-button>
          </el-upload>
        </el-descriptions-item>
        <el-descriptions-item label="username">
          <el-row >
            <p>{{ username() }}</p>
            <el-icon @click="showEditDialog" color="blue" size="large" style="margin-top: 3%;margin-left: 1%;"><Edit />
            </el-icon>
          </el-row>    
        </el-descriptions-item>
        <el-descriptions-item label="userId">{{ userId() }}</el-descriptions-item>
        <el-descriptions-item label="email">{{ email() }}</el-descriptions-item>
        <el-descriptions-item label="cancel account"><el-button type="danger" @click="handleDelete">Cancel</el-button></el-descriptions-item>
      </el-descriptions>
      
      
      <el-dialog title="modify username" v-model="dialogVisible" width="30%">
        <el-form>
          <el-form-item label="new username">
            <el-input v-model="newUsername" placeholder="plaese input new username"></el-input>
          </el-form-item>
        </el-form>
        <template #footer>
          <span class="dialog-footer">
            <el-button @click="dialogVisible = false">cancel</el-button>
            <el-button type="primary" @click="saveUsername">confirm</el-button>
          </span>
        </template>
      </el-dialog>
    </div>
</template>
  
<script setup>
import { ref} from 'vue';
import { ElAvatar, ElUpload, ElButton,ElMessage ,ElLoading} from 'element-plus';
import {Edit,} from '@element-plus/icons-vue';
import axios from 'axios';
import {useStore} from 'vuex'
import { useRouter } from 'vue-router';
const router=useRouter();
let loadingInstance = null;
const startLoading = () => {
  loadingInstance = ElLoading.service({
    lock: true,
    text: '加载中...',
    background: 'rgba(185, 180, 180, 0.5)'
  });
};
const endLoading = () => {
  if (loadingInstance) {
    loadingInstance.close();
  }
};
const store =useStore();
// 退出登录
const handleLogout = async () => {
  console.log('退出登录');
  // 清除用户会话信息
  store.dispatch("logout");
  router.push({
    path:"/"
  });
}
// 初始头像 URL
const avatarUrl = ()=>{
  return store.state.userImage;
} 
const username = ()=>{
  return store.state.userName;
}; // 用户名
const userId = ()=>{
  return store.state.userId;
} // 用户 ID
const email = ()=>{
  return store.state.email;
} // 邮箱
const uploadUrl=()=>{
  return store.state.requestPath+"/user/change_avatar";
}
const data=ref( {
    userId:store.state.userId
  })

const headers=ref(
  {
    token:store.state.token
  })

// 更换头像
const handleAvatarSuccess = (response,file,filelist) => {
    console.log(response);
    if(response.code==1){
        store.dispatch('changeImage', response.data);
        ElMessage.success("Successfully !");
    }else{
      ElMessage.error("Failed to change the avatar ");
    }
};

const beforeUpload = (file) => {
  const isImage = file.type.startsWith('image/');
  console.log(isImage);
  if (!isImage) {
    ElMessage.error('Only image file !');
  }
  return isImage;
};


const dialogVisible = ref(false);
const newUsername = ref(store.state.userName);

const showEditDialog = () => {
  dialogVisible.value = true;
};

const saveUsername = async () => {
  if (newUsername.value) {
    startLoading();
    try {
      const response = await axios.post(store.state.requestPath+"/user/change_user_name",{
        userId:store.state.userId,
        userName:newUsername.value
      },{
        headers:{
          token:store.state.token
        }
      });
      if (response.data.code!=1) {
        ElMessage.error(response.data.msg);
      } else {
        // 更新用户名
        store.dispatch("changeUserName",newUsername.value);
        dialogVisible.value = false;
        ElMessage.success('Successfully !');
        // 将用户信息返回后端
      }
      endLoading();
    } catch (error) {
      console.error('检查用户名失败', error);
      ElMessage.error('There is something wrong, please try again later !');
    }
  } else {
    ElMessage.warning('No Empty input !');
  }
};

// 用户注销
const handleDelete = async () => {
  // 处理注销逻辑
  console.log('用户注销');
  try {
        // 通知后端用户已注销
        await axios.post('/api/logout');

        // 清除用户会话信息
        localStorage.removeItem('userToken'); // 清除本地存储的令牌
        sessionStorage.removeItem('userInfo'); // 清除会话存储的用户信息

        // 重定向到主页面
        this.$router.push('/home');

        console.log('用户注销');
      } catch (error) {
        console.error('注销失败', error);
      }
}
</script>

<style scoped>

</style>