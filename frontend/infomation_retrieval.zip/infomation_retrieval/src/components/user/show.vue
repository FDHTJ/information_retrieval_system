<template>
  <div class="background-container">
    <el-container>
      <el-header class="header">
        <img :src="imageSrc" alt="描述文字" class="icon">
        <span class="title">Thesis Retrieval</span>
        <register></register>
        <span class="top-right" style="left: 70%;">User</span>
        <img :src="homePng" class="home" @click="backHome">
      <span class="top-right" style="left: 78.5%;">Home</span>
      <drawer/>
      <span class="top-right" style="left: 88%;">History</span>
      </el-header>
     
      <el-container>
        <el-aside width="15%">
      <el-scrollbar>
        <el-menu
        active-text-color="#ffd04b"
        background-color="rgba(255,255,255,0.1)"
        default-active="2"
        text-color="#fff"
        class="el-menu-vertical-demo"
        @open="handleOpen"
        @close="handleClose"
        @select="handleSelect"
      >
        <el-sub-menu index="1">
          <template #title>
            <el-icon><User /></el-icon>
            <span>Personal Info</span>
          </template>
          <el-menu-item-group>
            <el-menu-item index="1-1" >Basic Info</el-menu-item>
            <el-menu-item index="1-2" >Favorites</el-menu-item>
          </el-menu-item-group>
        </el-sub-menu>
        <el-sub-menu index="2">
          <template #title>
            <el-icon><Upload /></el-icon>
            <span>Upload</span>
          </template>
          <el-menu-item index="2-1">Upload Article</el-menu-item>
          <el-menu-item index="2-2">Analysis Article</el-menu-item>
        </el-sub-menu>
        <!-- 管理员菜单项 -->
        <el-sub-menu index="3" v-if="isAdmin()">
          <template #title>
            <el-icon><Setting /></el-icon>
            <span>Admin Rights</span>
          </template>
          <el-menu-item-group>
            <el-menu-item index="3-1">View UserList</el-menu-item>
            <el-menu-item index="3-2">Audit Article</el-menu-item>
          </el-menu-item-group>
        </el-sub-menu>
      </el-menu>
      </el-scrollbar>
    </el-aside>
        <el-main>
            <div class="info">
            <component :is="currentComponent"></component>
          </div>
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>

<script scope setup>
import { ref,onMounted } from 'vue';
import BasicInfo from './BasicInfo.vue';
import Favorites from './Favorites.vue';
import UploadArtile from './Upload.vue';
import UserList from './UserList.vue';
import Audit from './Audit.vue';
import homePng from '../../assets/diagram-06_24511.png';
import drawer from '../drawer.vue';
import register from '../register.vue';
import Analysis from './Analysis.vue';
import {User,Upload,Setting} from '@element-plus/icons-vue'
import imageSrc from '../../assets/analysis256_24853.png';
import { useRouter } from 'vue-router';
import {useStore} from 'vuex';
const store=useStore()
const router=useRouter();
const backHome=()=>{
  router.push({
    path:"/"
  });
}
const isAdmin = ()=>{
  return store.state.isManager;
};
const currentComponent = ref(BasicInfo);
const handleSelect = (index) => {
  console.log(index)
  switch (index) {
    case '1-1':
      currentComponent.value = BasicInfo;
      console.log(currentComponent.value);
      break;
    case '1-2':
      currentComponent.value = Favorites;
      console.log(currentComponent.value);
      break;
    case '2-1':
      currentComponent.value = UploadArtile;
      console.log(currentComponent.value);
      break;
    case '2-2':
      currentComponent.value = Analysis;
      console.log(currentComponent.value);
      break;
    case '3-1':
      currentComponent.value = UserList;
      break;
    case '3-2':
      currentComponent.value = Audit;
      break;
    default:
      currentComponent.value = BasicInfo;
      break;
  }
  console.log(currentComponent.value);
}



</script>

<style scoped>
.background-container {
    position: fixed; /* 使用 fixed 定位覆盖整个页面 */
    left: 0;
    top: 0;
    width: 100%; /* 宽度占满 */
    height: 100%; /* 高度占满 */
    background-image: url('https://wallpaperm.cmcm.com/7a0f5cb09d018636aa04b3bbdf5d4e30.jpg'); /*设置背景图片 */
    background-size: cover; /* 背景图片覆盖整个容器
    background-position: center; /* 背景图片居中 */
     /* 使用Flexbox布局 */
    flex-direction: column; /* 纵向排列 */
    justify-content: center; /* 垂直居中 */
    /* overflow-y: auto;  */
    /* 允许垂直方向滚动 */
    align-items: center; /* 水平居中 */
}
.el-header {
  /* 设置背景颜色 */
  color: white;
  background-color: rgba(255, 255, 255, 0);
  width: 100%;
  height: 20%;
  padding: 0px;/* 设置内边距 */
  border-bottom: 2px solid rgb(153, 152, 152);
}
  
.header {
    /* background: linear-gradient(to top, rgba(255, 255, 255, 0), rgba(97, 96, 96, 0.9)); 从下到上渐变 */
    /* background-color: rgba(255, 255, 255, 0.7); 半透明背景色 */
    padding-top: 15px;
    text-align: left;
    width: 100%;
  }

.logout-button {
  position: relative; /* 绝对定位 */
   /* 距离底部的距离 */
  left: 90%; /* 距离左侧的距离 */
}
.el-aside{
  background: rgb(133, 133, 134);
  padding: 0px;/* 设置内边距 */
  border-right: 2px solid rgb(153, 152, 152);

}
.el-menu{
  background: none;
}
.el-sub-menu{
  background: none;
}
el-menu-item{
  background: none;
}
.info {
    width: 95%;
    height: fit-content;
    background-color: rgba(255, 255, 255, 0.9);
    border-radius: 15px;
    padding: 30px;
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5); /* 阴影效果 */
    position: relative; /* 使分页容器可以相对于 .info 定位 */
    display: flex;
    flex-direction: column;
}
.el-container {
  height: 100%;
  overflow-y: hidden;
  overflow-x: hidden;
}

/* 确保主内容区域占满剩余高度 */
.el-main {
   width: 100%;
  height: auto;
}
.title {
    position: absolute;
    top: 15px;
    left: 135px;
    font-size: 26px;
    color: #ffffff;
    font-weight: bold;
    font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
  }

  .top-right {
  position: absolute;
  top: 25px;
  font-size: 22px;
  color: #e7e5e5;
  font-weight: bold;
  font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
}
.home {
  height: 40px; 
  position: relative;
  left: 75%;
  cursor: pointer;
}
.icon {
  position: absolute; /* 绝对定位 */
  top: 12px; /* 距离上边缘20px */
  left: 80px; /* 距离左边缘20px */
  width: 50px;
  height: 40px;
  margin-right: 10px; /* 图标与文字之间的间距 */
}
</style>