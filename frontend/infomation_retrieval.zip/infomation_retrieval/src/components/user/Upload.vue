<template>
  <div style="height: 80%">
    <h1 style="font-size: 20px;color: rgba(0,0,0,0.7);">Upload Article</h1>
    <el-divider />
    <el-upload
    class="upload-demo"
    drag
    :before-upload="beforeUpload"
    :http-request="uploadFile"
    multiple>
    <el-icon class="el-icon--upload"><upload-filled /></el-icon>
    <div class="el-upload__text">
      Drop file here or <em>click to upload</em>
    </div>
  </el-upload>
  <el-table :data="pendingList" style="width: 100%">
      <el-table-column prop="originalFileName" label="filename" />
      <el-table-column prop="uploadDate" label="upload date" />
      <el-table-column prop="state" label="state" width="150px">
        <template #default="scope">
          <span :style="getStateStyle(scope.row.state)">{{ scope.row.state }}</span>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script setup>
import { UploadFilled, } from '@element-plus/icons-vue';
import { ElMessage,ElUpload,ElLoading} from 'element-plus';
import axios from 'axios';
import { useStore } from 'vuex';
import { onMounted, ref } from 'vue';
const store=useStore();
const beforeUpload = (file) => {
  const isPDF = file.type === 'application/pdf';
  if (!isPDF) {
    ElMessage.error('Only pdf files !');
  }
  const maxSize = 15 * 1024 * 1024; // 5MB in bytes

      // 获取文件大小
      const fileSize = file.size;

      // 检查文件大小是否超过限制
      if (fileSize > maxSize) {
        ElMessage.error("File is too large !");
        return false; // 返回 false 取消上传
      }
  return isPDF;
};
let loadingInstance = null;
const startLoading = () => {
  loadingInstance = ElLoading.service({
    lock: true,
    text: '加载中...',
    background: 'rgba(185, 180, 180, 0.5)'
  });
};
const endLoading = () => {
  if (loadingInstance) {
    loadingInstance.close();
  }
};
const uploadFile = async(options) => {
  startLoading();
  const formData = new FormData();
  formData.append('file', options.file);
// 上传文件
  await axios.post(store.state.requestPath+"/user/upload", formData, {
    headers: {
      'Content-Type': 'multipart/form-data',
      token:store.state.token
    },
    params:{
      userId:store.state.userId
    }
  })
  .then(response => {
    console.log(response);
    if(response.data.code!=1){

      ElMessage.error(response.data.msg);
      
    }else{
      ElMessage.success('Successful !');
      fetchPendingList();
    }
    
  })
  .catch(error => {
    ElMessage.error('Failed !');
    console.error('Upload error:', error);
  }).finally(e=>{
    endLoading();
  });
};
const pendingList = ref([
  {
    originalFileName: 'sample1.pdf',
    uploadDate: '2023-10-01T12:34:56Z',
    state:'pending review'
  }
  
]);
const fetchPendingList = async() => {
  // 获得待审核列表
      await axios.get(store.state.requestPath+"/user/get_upload_record",{
        params:
        {
          userId:store.state.userId
        },
        headers:{
          token:store.state.token
        }
      })
        .then(response => {
          console.log(response);
          pendingList.value = response.data.data;
        })
        .catch(error => {
          ElMessage.error("There is something wrong ,Please try again later!");
          console.error('Fetch pending list error:', error);
        });
    };

onMounted(() => {
  fetchPendingList(); // 初始化时获取待审核列表
});

const getStateStyle = (state) => {
  if (state === 'Wait for auditing ') {
    return { color: 'orange' };
  } else if (state === 'Pass') {
    return { color: 'green' };
  }else if(state==='Failed'){
    return {color:'red'}
  }
  return {};
};
</script>
