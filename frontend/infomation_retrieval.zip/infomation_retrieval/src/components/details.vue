<template>
  <div class="background-container">
    <el-header class="header">
      <img :src="imageSrc" alt="描述文字" class="icon">
      <span class="title">Thesis Retrieval</span>
      <register></register>
        <span class="top-right" style="left: 70%;">User</span>
      <img :src="homePng" class="home" @click="backHome">
      <span class="top-right" style="left: 78.5%;">Home</span>
      <drawer />
      <span class="top-right" style="left: 88%;">History</span>
    </el-header>
    <el-main class="main">
      <detailsMore/>
    </el-main>
  </div>

</template>

<script setup>
import imageSrc from '@/assets/analysis256_24853.png';
import detailsMore from './detailsMore.vue';
import { useRouter } from 'vue-router';
import homePng from '@/assets/diagram-06_24511.png';
import drawer from './drawer.vue';
import register from './register.vue';
const router=useRouter();
const backHome=()=>{
  router.push({
    path:"/"
  });
}
</script>


<style scoped>
* {
  margin:0;
  padding: 0;
  box-sizing: border-box;
}
html, body {
  margin: 0; /* 移除页面的默认外边距 */
  padding: 0; /* 移除页面的默认内边距 */
  height: 100%; /* 设置高度为100% */
  width: 100%;
  overflow-x: hidden; /* 禁止水平滚动 */
}
.background-container {
  position: fixed; /* 使用 fixed 定位覆盖整个页面 */
  left: 0;
  top: 0;
  width: 100%; /* 宽度占满 */
  height: 100vh; /* 高度占满 */
  background-image: url('https://wallpapercave.com/wp/wp5103807.jpg'); /*设置背景图片 */
  background-size: cover; /* 背景图片覆盖整个容器*/
  background-position: center; /* 背景图片居中 */
  display: flex; /* 使用Flexbox布局 */
  flex-direction: column; /* 纵向排列 */
  justify-content: center; /* 垂直居中 */
  align-items: center; /* 水平居中 */
}

.header {
  background: linear-gradient(to top, rgba(255, 255, 255, 0), rgba(34, 33, 33, 0.8)); /* 从下到上渐变 */
  /* background-color: rgba(255, 255, 255, 0.7); 半透明背景色 */
  padding-top: 15px;
  text-align: left;
  width: 100%;
  height: 65px;
  margin-bottom: 40px;
}

.main {
  width: 100%;
  flex: 1; /* 主内容区域扩展以占满剩余空间 */
}
.main[data-v-8a085adb] {
  margin-left: 10%;
}

.icon {
  position: absolute; /* 绝对定位 */
  top: 12px; /* 距离上边缘20px */
  left: 80px; /* 距离左边缘20px */
  width: 50px;
  height: 40px;
  margin-right: 10px; /* 图标与文字之间的间距 */
}

.title {
  position: absolute;
  top: 10px;
  left: 135px;
  font-size: 26px;
  color: #e7e5e5;
  font-weight: bold;
  font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
}
.top-right {
  position: absolute;
  top: 25px;
  font-size: 22px;
  color: #e7e5e5;
  font-weight: bold;
  font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
}
.home {
  height: 40px; 
  position: relative;
  left: 75%;
  cursor: pointer;
}
.home:hover {
  opacity: 0.8;
}
</style>