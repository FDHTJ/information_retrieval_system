<template>
    <div class="search-frame">
      <el-select
        v-model="field"
        clearable
        @change="querySearch"
        placeholder="Select Subject"
        style="width: 22%; height: 61px;"
      >
        <el-option
          v-for="item of categories"
          :key="item.value"
          :label="item.label"
          :value="item.value"
          
        />
      </el-select>
      <!-- 输入框 -->
      <el-autocomplete
        v-model="query"
        :fetch-suggestions="querySearch"
        :trigger-on-focus="false"
        clearable
        placeholder="Please Input"
        @select="handleSelect"
        @keydown.enter="performSearch"
      />
      <button @click="performSearch" class="search-button">Search</button>
    </div>
</template>

<script >
import { ref, onMounted} from 'vue';
import { useRouter } from 'vue-router/dist/vue-router';
import axios from 'axios';
import { ElMessage } from 'element-plus';
import { useStore } from 'vuex';
export default {
  data() {
    return {
      
    }
  },
  setup() {
    const field = ref('title')
    const categories = ref([
      {
        value: 'title',
        label: 'title',
      },
      {
        value: 'digest',
        label: 'digest',
      },
      {
        value: 'writers',
        label: 'writers',
      },
      {
        value: 'keywords',
        label: 'keywords',
      },
      {
        value: 'fulltext',
        label: 'fulltext',
      },
      {
        value: 'addresses',
        label: 'addresses',
      },
      {
        value: 'orgNames',
        label: 'orgNames',
      },
    ])
    const store=useStore();
    // 创建响应式变量query用来存储用户在搜索框中输入的文本
    const query = ref('');
    const router=useRouter()
    const performSearch = () => {
      if(query.value.startsWith('*')||query.value.startsWith('?')||query.value.startsWith('？')){
        ElMessage.error("'*' or '?' not allowed as first character in WildcardQuery");
        return ;
      }
      if(query.value==""){
        ElMessage.error("Input can't be empty !")
        return;
      }
      router.push({
        path:'/searchResult',
        query:{
          field:field.value,
          queryText:query.value,
          dateChoice:0,
          currentPage:1
        }
      });
    };
  
    const restaurants = ref([])
    const querySearch = (queryString, cb) => {
      try{
        getSuggest(cb);
      //const results = restaurants.value
      // call callback function to return suggestions
      }catch(error){
        console.log("错误")
      }
      
    }
    const getSuggest=async(cb)=>{
      if(query.value==""){
        cb([])
        return;
      }
      if(query.value.startsWith('*')||query.value.startsWith('?')||query.value.startsWith('？')){
        ElMessage.error("'*' or '?' not allowed as first character in WildcardQuery");
        return ;
      }
      
      try{
        const response=await axios.get(store.state.requestPath+"/search/get_suggest",{
          params:
        {
          "field":field.value,
          "queryText":query.value,
        }
        }
       );
       console.log(response.data.data)
       restaurants.value=[]
       for(var s of response.data.data){
          restaurants.value.push({value:s,link:""});
       }
       cb(restaurants.value);
      }catch(error){
        console.log(error)
        cb([])
        console.log("错误");
      }
      
    }
   
   

    const handleSelect = (item) => {
      console.log(item)
    }

    onMounted(() => {
    })

    return {
      field,
      categories,
      query, 
      performSearch,
      querySearch,
      handleSelect,
    };
  }
}
</script>

<style scoped>
/* scoped：让当前样式只在当前组件中生效 */
/* 下拉框 */
:deep(.el-select__wrapper) {
  height: 100% !important;
  width: 100% !important;
  align-items: center !important;
  justify-content: center !important;
  border-radius: 15px 0 0 15px !important;
  border-top: none;
  border-bottom: none;
  border-left: none;
  font-size: 16px;
}


/* 搜索框架 */
.search-frame {
  position: relative;
  background-color: rgba(255, 255, 255); /* 背景色 */
  border-radius: 15px; /* 圆弧边框 */
  margin-left: 350px; 
  margin-right: 350px; 
  margin-bottom: 350px; 
  margin: 100px auto 50px; /* 上下间距，左右自动居中 */
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5); /* 阴影效果 */
  display: flex;
  justify-content: center;
  align-items: center; /* 在垂直方向上居中对齐 */
  width: 70%;
  max-width: 695px;
  overflow: hidden;
}
/* 输入字体格式 */
.search-input {
  flex: 1;
  padding: 18px;
  font-size: 16px;
  border: none;
  outline: none;
}
/* 搜索按钮 */
.search-button {
  width: 20%;
  padding: 21px 20px;
  background-color: white;
  color: #5e5b5b;
  font-size: 16px;
  border: none;
  border-radius: 0 15px 15px 0;
  cursor: pointer; /* 悬停时变成手形光标 */
}
.search-button:hover {
  color:white;
  background-color: #409EFF;
}
/* 建议列表 */
.suggestions {
  border: 1px solid #ccc;  /* 建议列表边框 */
  background-color: white;  /* 建议列表背景色 */
  position: absolute;  /* 绝对定位，使其浮在输入框下方 */
  top: 100%;
  left: 22%;
  width: 78%;  /* 建议列表宽度与输入框相同 */
  z-index: 10;  /* 设置 z-index 以确保建议在其他元素之上 */
}
/* 建议项 */
:deep(.suggestion-item) {
  background-color: white !important;
  color: #5e5b5b !important;
  padding: 10px !important;  /* 建议项内边距 */
  cursor: pointer !important;  /* 鼠标悬停时显示手型光标 */
}
:deep(.el-autocomplete) {
 width: 60%;
 height: 100%;
}

:deep(.el-input__wrapper) {
   height: 61px;
 border-radius: 0;
 font-size: 16px;
}
:deep(.suggestion-item:hover) {
  background-color: #f0f0f0;  /* 鼠标悬停时改变背景色 */
}
</style>