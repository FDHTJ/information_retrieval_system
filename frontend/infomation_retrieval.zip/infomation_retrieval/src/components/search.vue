<template>
  <div class="background-container">
    <el-container>
      <!-- 输入框 -->
      <el-header>
        <el-row class="header">
          <img :src="imageSrc" alt="描述文字" class="icon">
        <span class="title1">Thesis Retrieval</span>
        <register></register>
        <span class="top-right" style="left: 70%;">User</span>
        <img :src="homePng" @click="backHome" class="home">
      <span class="top-right" style="left: 78.5%;">Home</span>
      <drawer/>
      <span class="top-right" style="left: 88%;">History</span>
        </el-row>
        <el-row style="height:40px; margin-left:90px ; margin-top:50px ; margin-bottom: 30px;">
          <el-col :span="2" style="height:100%">
            <!-- 检索项 -->
            <div class="custom-select" @click="toggleDropdown">
              <div class="selected-option">
                <span style="padding: 20px;">{{ selectedOption }}</span>
              </div>
              <div v-if="showDropdown" class="dropdown">
                <div v-for="option in options" :key="option.value" class="dropdown-item"
                  :class="{ 'selected': selectedOption === option.value }" @click="selectOption(option.value)">
                  {{ option.label }}
                </div>
              </div>
            </div>
          </el-col>

          <el-col :span="6" style="height:100%">
            <el-autocomplete
        v-model="input"
        :fetch-suggestions="querySearch"
        :trigger-on-focus="false"
        clearable
        style="width: 100%;height:100%;font-size:16px;border: none;outline:none; box-sizing: border-box;box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1), 0 -2px 4px rgba(0, 0, 0, 0.1);"
        placeholder="Please Input"
        @keydown.enter="handleSearch"
        @select="handleSelect"
      />
            <!-- 输入框 -->
            <!-- <input v-model="input"
              style="width: 100%;height:100%;font-size:16px;border: none;outline:none;padding-left: 10px; box-sizing: border-box;box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1), 0 -2px 4px rgba(0, 0, 0, 0.1); /* 添加上下边框阴影 */"
              placeholder="Please input" /> -->
          </el-col>
          <el-col :span="6" style="height:100%">
            <!-- 搜索按钮 -->
            <button class="search-button" @click="search">Search</button>
          </el-col>
        </el-row>
      </el-header>
      <el-container>
        <el-aside  @change="selectionChange" style="width:200px; border-right: 2px solid rgba(153, 152, 152, 1);">
          <el-radio-group v-model="radio" style="margin: 20px;">
          <el-radio :value="0">Any Time</el-radio>
          <el-radio :value="1">Since 2000</el-radio>
          <el-radio :value="2">Since 1900</el-radio>

          </el-radio-group>
        </el-aside>
        <el-main v-if="!hasResult">
          <el-empty  :image-size="200" description="No Result! Please check input!" />
        </el-main>
          <el-main v-if="hasResult" id="mainContent">
          <!-- 搜索结果显示 -->
          <div class="search_result">
            
            <div v-for="(description,index) in descriptions" :key="index" class="description-card">
              <el-link @click="goDetails(index)" target="_blank" class="title" v-html="description.title"></el-link>
              <div v-for="(item, itemIndex) in description.items" :key="itemIndex" class="item">
                <span class="label">{{ item.label }}</span>
                <span class="value" v-html="item.value"></span>
              </div>
            </div>
            <el-pagination  @current-change="pageChange" :current-page="currentPage" layout="prev, pager, next" :page-count="currentPage+1" />
          </div>
          
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>

<script scope setup>
import { ref } from 'vue'
import axios from 'axios'
import imageSrc from '@/assets/analysis256_24853.png'
import { ElText ,ElLoading, ElMessage} from 'element-plus';
import { useRoute,useRouter } from 'vue-router/dist/vue-router';
import homePng from '@/assets/diagram-06_24511.png';
import drawer from './drawer.vue';
import register from './register.vue';
import { useStore } from 'vuex';
const route=useRoute();
const router=useRouter();
const store=useStore();
let loadingInstance = null;
const startLoading = () => {
  loadingInstance = ElLoading.service({
    lock: true,
    text: '加载中...',
    background: 'rgba(185, 180, 180, 0.5)'
  });
};
const backHome=()=>{
  router.push({
    path:"/"
  });
}
const endLoading = () => {
  if (loadingInstance) {
    loadingInstance.close();
  }
};
/* 请求的搜索数据 */
const currentPage=ref(Number(route.query.currentPage));
const maxPage=ref(1000)
const handleSearch = async () => {
  if(input.value==""){
    ElMessage.error('The input can\'t be empty !')
    return;
  }
  if(input.value.startsWith('*')||input.value.startsWith('?')||input.value.startsWith('？')){
        ElMessage.error("'*' or '?' not allowed as first character in WildcardQuery");
        return ;
      }
  try {
    //每次设置最大值，如果说存在
    
    startLoading();
    const response = await axios.get(store.state.requestPath+"/search/get_search_result", {
      params: {
        "field": selectedOption.value,
        "queryText": input.value,
        "currentPage":currentPage.value,
        "dateChoice":radio.value,
      }
    });
    console.log(response.data.data);
    all_data.value = response.data.data;
    var i=1;
    descriptions.value = []
    for (var article of all_data.value) {
      // var temp={}
      // temp['link']=article["fileName"];
      // temp['title']=article['title'];
      // temp["items"]=[]
      // temp["items"].push({label:'date',value:article['date']});
      // temp["items"].push({label:'writers',value:article['writers']});
      // temp["items"].push({label:'digest',value:article['digest']});
      console.log(article["fileName"]);
      if(selectedOption.value!="title" && selectedOption.value!="digest"&&selectedOption.value!="fulltext"){
        descriptions.value.push(
        {
          link: article["fileName"] == "" ? "unknown" : article["fileName"],
          title: i+"."+ (article["title"] == "" ? "unknown" : article["title"]),
          items: [
            { label: 'date', value: article["date"] == "" ? "unknown" : article["date"] },
            { label: selectedOption.value, value: article[selectedOption.value] == "" ? "unknown" : article[selectedOption.value] },
            { label: 'digest', value: article["digest"] == "" ? "unknown" : article["digest"]}
          ]
        }
      );

      }else{
        descriptions.value.push(
        {
          link: article["fileName"] == "" ? "unknown" : article["fileName"],
          title: i+"."+ (article["title"] == "" ? "unknown" : article["title"]),
          items: [
            { label: 'date', value: article["date"] == "" ? "unknown" : article["date"] },
            { label: "writers", value: article["writers"] == "" ? "unknown" : article["writers"] },
            { label: 'digest', value: article["digest"] == "" ? "unknown" : article["digest"]}
          ]
        }
      );
      }
      
      i++;
    }
    maxPage.value=1000;
    if(descriptions.value.length<10){
      //说明这个时候没有下一页了
      maxPage.value=currentPage.value;
    }
    if(descriptions.value.length!=0){
      hasResult.value=true;
    }else{
      hasResult.value=false;
    }

  } catch (error) {
    console.log(error)
    ElMessage.error('This is something wrong ! please try again!')
  }finally{
    endLoading();
    var v=document.getElementById("mainContent");
    v.scrollTo(0,0);
  }
}
const search=()=>{
  currentPage.value=1;
  handleSearch();
}
const pageChange=(newPage)=>{
  if(newPage>=maxPage.value){
    ElMessage.info("Don't have more result !");
    return;}
  currentPage.value=newPage;
  console.log(currentPage.value);
  handleSearch();

}
const selectionChange=()=>{
  currentPage.value=1;
  handleSearch();
}
const radio=ref(Number(route.query.dateChoice));
// 输入框数据
const input = ref(route.query.queryText);
const hasResult=ref(false);
const all_data = ref([]);
// 检索项数据
const selectedOption = ref(route.query.field);
handleSearch();
const showDropdown = ref(false);
// 搜索结果数据
// 使用 ref 定义 descriptions 数据
const descriptions = ref([]);
const restaurants = ref([]);
    const querySearch = (queryString, cb) => {
      try{
        getSuggest(cb);
      //const results = restaurants.value
      // call callback function to return suggestions
      }catch(error){
        console.log("错误")
      }
      
    }
    const getSuggest=async(cb)=>{
      currentPage.value=1;
      if(input.value==""){
        cb([])
        return;
      }
      if(input.value.startsWith('*')||input.value.startsWith('?')||input.value.startsWith('？')){
        ElMessage.error("'*' or '?' not allowed as first character in WildcardQuery");
        return ;
      }
      try{
        const response=await axios.get(store.state.requestPath+"/search/get_suggest",{

          params:
        {
          "field":selectedOption.value,
          "queryText":input.value,
        }
        }
       );
       console.log(response.data.data)
       all_data.value=response.data.data;
       restaurants.value=[]
       for(var s of response.data.data){
          restaurants.value.push({value:s,link:""});
       }
       cb(restaurants.value);
      }catch(error){
        console.log(error)
        cb([])
        console.log("错误");
      }
      
    }
   

    const handleSelect = (item) => {
      console.log(item)
    }
const options = [
  { value: 'writers', label: 'writers' },
  { value: 'title', label: 'title' },
  { value: 'addresses', label: 'addresses' },
  { value: 'fulltext', label: 'fulltext' },
  { value: 'digest', label: 'digest' },
  { value: 'keywords', label: 'keywords' },
  { value: 'orgNames', label: 'orgNames' },
];
//检索项下拉菜单
const toggleDropdown = () => {
  showDropdown.value = !showDropdown.value;
};
const selectOption = (value) => {
  selectedOption.value = value;
  toggleDropdown;
};

const goDetails=async(index)=>{
  var dic={};
  for(const[key,value] of Object.entries(all_data.value[index])){
    if(value==""){
      dic[key]="unknown";
    }else{
      dic[key]=value;
    }
  }
  if(store.state.isLoggedIn && dic["title"] !="unknown"){
    try{
    await axios.post(store.state.requestPath+"/user/add_history",{
      userId:store.state.userId,
      title:dic['title'],
    },{
      headers:
      {
        token:`${store.state.token}`
      },
    });
  }catch{
  }
  }
  
    router.push({
      path:"/details",
      query:{
        article: JSON.stringify(dic),
        currentPage:currentPage.value,
        dateChoice:radio.value,
        queryText:input.value,
        field:selectedOption.value
      }
    });
}
</script>


<style scoped>
:deep(.body) {
  margin: 0px;
}
:deep(.el-container is-vertical){
  height: 100% !important;
  width: 100% !important;
}
.el-header {
  
  /* 设置背景颜色 */
  color: white;
  background-color: rgba(255, 255, 255, 0.4);
  width: 100%;
  height: 25%;
  /* 设置文字颜色 */
  padding: 0px;
  /* 设置内边距 */
  border-bottom: 2px solid rgb(153, 152, 152);
}
.search-button {
  position: relative;
  /* 设置相对定位，使得伪元素可以相对于它进行绝对定位 */
  width: 80px;
  height: 100%;
  background-color: #409EFF;
  color: white;
  border: none;
  /* 移除按钮的边框 */
  outline: none;
  /* 移除按钮的轮廓 */
  cursor: pointer;
  /* 设置鼠标指针为手型，表示可点击 */
  overflow: hidden;
  /* 隐藏溢出内容，防止伪元素超出按钮范围 */
  border-top-right-radius: 20px;
  /* 圆弧部分 */
  border-bottom-right-radius: 20px;
  /* 圆弧部分 */
  box-shadow: 2px 2px 4px rgba(0, 0, 0, 0.2), 0px -2px 4px rgba(0, 0, 0, 0.2);
}

.custom-select {
  position: relative;
  width: 100%;
  height: 100%;
  border-radius: 20px 0 0 20px;
  box-shadow: -2px 2px 4px rgba(0, 0, 0, 0.1), 0 -2px 4px rgba(0, 0, 0, 0.1);
  color: #409EFF;
  cursor: pointer;
  background-color: #fff;
  text-align: center;
  display: flex;
  align-items: center;
}

.selected-option {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  font-size: 14px;
}

.dropdown {
  position: absolute;
  top: 100%;
  left: 0;
  width: 100%;
  background-color: #fff;
  border: 1px solid #ccc;
  border-radius: 20px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  z-index: 10;
}

.dropdown-item {
  padding: 10px;
  cursor: pointer;
  transition: background-color 0.3s;
  text-align: center;
}

.dropdown-item:hover {
  background-color: #409EFF;
  color: #fff;
  opacity: 0.3;
  border-radius: 20px;
}

.dropdown-item.selected {
  background-color: #409EFF;
  color: #fff;
  border-radius: 20px;
}


.search_result {
  /* padding: 10px; */
  /* background-color: rgba(255, 255, 255, 0.85); */
  margin-bottom: 60px;
}

.description-card {
  border: 1px solid #e0e0e0;
  border-radius: 4px;
  margin-bottom: 20px;
  padding: 10px;
  background-color: rgb(255, 249, 249, 0.8);
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
}

.description-card .title {
  color:#000000;
font-size:20px;
font-weight: bold;
margin-bottom:10px;display:-webkit-box;
-webkit-box-orient:vertical;-webkit-line-clamp:1;/*限制为一行 */
line-clamp:1;
overflow:hidden;
text-overflow:ellipsis;
white-space:normal;/*允许换行*/
}

.description-card .item {
  display:-webkit-box;
  margin-bottom:10px;
  font-size:15px;
-webkit-box-orient:vertical;
-webkit-line-clamp:2;/*限制为二行 */
line-clamp:2;overflow:hidden;
text-overflow:ellipsis;
white-space:normal;/*允许换行*/
}

.description-card .label {
  font-weight: bold;
  margin-right: 10px;
  min-width: 100px;
}

.description-card .value {
  flex: 1;
}

/* .example-pagination-block+.example-pagination-block {
  /* margin-top: 10px; */
/* } */

/* .example-pagination-block .example-demonstration {
  /* margin-bottom: 16px; */
/* } */
.el-container{
  background-color: rgba(255, 255, 255, 0.4);
  height: 100%;
}
.el-main{
  width: 100%;
  height: 85%;
}
.header {
    background: linear-gradient(to top, rgba(255, 255, 255, 0), rgba(144, 142, 142, 0.8)); /* 从下到上渐变 */
    /* background-color: rgba(255, 255, 255, 0.4); 半透明背景色 */
    padding-top: 0px;
    text-align: left;
    width: 100%;
    height: 40px;
  }
  
  
  .icon {
    position: absolute; /* 绝对定位 */
    top: 12px; /* 距离上边缘20px */
    left: 80px; /* 距离左边缘20px */
    width: 50px;
    height: 40px;
    margin-right: 10px; /* 图标与文字之间的间距 */
  }
  
  .title1 {
    position: absolute;
    top: 20px;
    left: 135px;
    font-size: 26px;
    color: #7a7878;
    font-weight: bold;
    font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
  }
  .background-container {
    position: fixed; /* 使用 fixed 定位覆盖整个页面 */
    left: 0;
    top: 0;
    width: 100%; /* 宽度占满 */
    height: 100vh; /* 高度占满 */
    background-image: url('https://wallpaperm.cmcm.com/7a0f5cb09d018636aa04b3bbdf5d4e30.jpg'); /*设置背景图片 */
    background-size: cover; /* 背景图片覆盖整个容器
    background-position: center; /* 背景图片居中 */
     /* 使用Flexbox布局 */
    flex-direction: column; /* 纵向排列 */
    justify-content: center; /* 垂直居中 */
    /* overflow-y: auto;  */
    /* 允许垂直方向滚动 */
    align-items: center; /* 水平居中 */
  }
  :deep(.el-empty__description p){
    color:#757474;
    font-size: 20px;
  }

  :deep(.el-input__wrapper) {
   height: 39px;
 border-radius: 0;
 font-size: 16px;
}
.top-right {
  position: absolute;
  top: 25px;
  font-size: 22px;
  color: #7a7878;
  font-weight: bold;
  font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
}
.home {
  height: 40px; 
  position: relative;
  left: 75%;
  top: 18px;
  cursor: pointer;
}
.home:hover {
  opacity: 0.8;
}

</style>