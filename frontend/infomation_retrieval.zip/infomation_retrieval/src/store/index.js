import {createStore} from 'vuex'
export default createStore({
   
  state: {
    requestPath:"http://localhost:8080", 
    isLoggedIn: false,  // 默认用户未登录
    userId : 1,//用户ID
    userName: '',//用户名
    email:'',//邮箱
    token:'',//token
    isManager:false,//是否是管理员
    userImage:'https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png',//用户头像链接

  },
  mutations: {
    Login(state,userInfo) {
    state.isLoggedIn=true;// 修改登录状态
    state.userId =      userInfo.userId;
    state.userName=     userInfo.userName;
    state.email=        userInfo.email;
    state.token=        userInfo.token;
    state.isManager=    userInfo.isManager;
    state.userImage=    userInfo.userImage;
    },
    Logout(state){
    state.isLoggedIn=false;
    state.userId = null;
    state.userName= '';
    state.email='';
    state.token='';
    state.isManager=false;
    state.userImage='https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png';
    },
    changeImage(state,imageUrl){
      state.userImage=imageUrl;
    },
    changeUserName(state,userName){
      state.userName=userName;
    },
  },
  actions: {
    login({ commit },userInfo) {
      commit('Login', userInfo);  // 用户登录
    },
    logout({ commit }) {
      commit('Logout');  // 用户登出
    },
    changeImage({commit},imageUrl){
      commit('changeImage',imageUrl);
    },
    changeUserName({commit},userName){
      commit('changeUserName',userName);
    }
  },
});

